import { createContext, ReactNode, useCallback, useContext, useEffect, useState } from 'react';
import { api } from '../lib/api';
import type { ConversationSummary } from '../lib/types';
import { useAuth } from './useAuth';

interface ConversationsState {
  conversations: ConversationSummary[];
  loading: boolean;
  refresh: () => Promise<void>;
  rename: (id: string, title: string) => Promise<void>;
  remove: (id: string) => Promise<void>;
  removeAll: () => Promise<void>;
}

const Ctx = createContext<ConversationsState>({
  conversations: [],
  loading: false,
  refresh: async () => {},
  rename: async () => {},
  remove: async () => {},
  removeAll: async () => {},
});

export function ConversationsProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [conversations, setConversations] = useState<ConversationSummary[]>([]);
  const [loading, setLoading] = useState(false);

  const refresh = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const res = await api<{ conversations: ConversationSummary[] }>('/conversations');
      setConversations(res.conversations);
    } catch {
      /* keep the previous list */
    } finally {
      setLoading(false);
    }
  }, [user?.id]);

  useEffect(() => {
    if (user) refresh();
    else setConversations([]);
  }, [user?.id, refresh]);

  const rename = useCallback(async (id: string, title: string) => {
    await api(`/conversations/${id}`, { method: 'PATCH', json: { title } });
    setConversations((list) => list.map((c) => (c.id === id ? { ...c, title } : c)));
  }, []);

  const remove = useCallback(async (id: string) => {
    await api(`/conversations/${id}`, { method: 'DELETE' });
    setConversations((list) => list.filter((c) => c.id !== id));
  }, []);

  const removeAll = useCallback(async () => {
    await api('/conversations', { method: 'DELETE' });
    setConversations([]);
  }, []);

  return <Ctx.Provider value={{ conversations, loading, refresh, rename, remove, removeAll }}>{children}</Ctx.Provider>;
}

export const useConversations = () => useContext(Ctx);
