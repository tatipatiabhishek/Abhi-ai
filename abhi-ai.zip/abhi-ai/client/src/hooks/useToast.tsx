import { ReactNode, useCallback, useEffect, useRef, useState } from 'react';

/** Tiny toast helper: `show('Saved')` then render `{node}` somewhere in the page. */
export function useToast() {
  const [message, setMessage] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout>>();

  const show = useCallback((text: string) => {
    setMessage(text);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setMessage(null), 2600);
  }, []);

  useEffect(() => () => clearTimeout(timer.current), []);

  const node: ReactNode = message ? (
    <div className="pointer-events-none fixed inset-x-0 bottom-24 z-50 flex justify-center px-4 md:bottom-8" role="status">
      <div className="animate-fadeUp rounded-full border border-line bg-panel px-4 py-2 text-sm shadow-xl">{message}</div>
    </div>
  ) : null;

  return { show, node };
}
