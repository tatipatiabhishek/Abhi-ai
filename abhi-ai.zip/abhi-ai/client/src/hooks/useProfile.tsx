import { createContext, ReactNode, useCallback, useContext, useEffect, useState } from 'react';
import { api } from '../lib/api';
import type { Profile } from '../lib/types';
import { useAuth } from './useAuth';

const DEFAULTS: Profile = {
  id: '',
  display_name: '',
  language: 'en',
  voice_enabled: true,
  voice_rate: 1,
  model: null,
  web_search: true,
  memory_enabled: true,
};

interface ProfileState {
  profile: Profile;
  models: string[];
  defaultModel: string;
  loaded: boolean;
  update: (patch: Partial<Omit<Profile, 'id'>>) => Promise<void>;
}

const ProfileContext = createContext<ProfileState>({
  profile: DEFAULTS,
  models: [],
  defaultModel: '',
  loaded: false,
  update: async () => {},
});

export function ProfileProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [profile, setProfile] = useState<Profile>(DEFAULTS);
  const [models, setModels] = useState<string[]>([]);
  const [defaultModel, setDefaultModel] = useState('');
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    if (!user) {
      setProfile(DEFAULTS);
      setLoaded(false);
      return;
    }
    let cancelled = false;
    Promise.all([api<{ profile: Profile }>('/profile'), api<{ models: string[]; default: string }>('/models')])
      .then(([p, m]) => {
        if (cancelled) return;
        setProfile({ ...DEFAULTS, ...p.profile });
        setModels(m.models);
        setDefaultModel(m.default);
      })
      .catch(() => {
        /* the chat page shows connection errors; defaults keep the UI usable */
      })
      .finally(() => !cancelled && setLoaded(true));
    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  const update = useCallback(async (patch: Partial<Omit<Profile, 'id'>>) => {
    setProfile((p) => ({ ...p, ...patch })); // optimistic
    try {
      const res = await api<{ profile: Profile }>('/profile', { method: 'PATCH', json: patch });
      setProfile((p) => ({ ...p, ...res.profile }));
    } catch (e) {
      // Reload the real values if saving failed.
      api<{ profile: Profile }>('/profile').then((r) => setProfile({ ...DEFAULTS, ...r.profile })).catch(() => {});
      throw e;
    }
  }, []);

  return <ProfileContext.Provider value={{ profile, models, defaultModel, loaded, update }}>{children}</ProfileContext.Provider>;
}

export const useProfile = () => useContext(ProfileContext);
