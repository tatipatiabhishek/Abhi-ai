import { useCallback, useEffect, useState } from 'react';

type Theme = 'dark' | 'light';

function current(): Theme {
  return document.documentElement.classList.contains('dark') ? 'dark' : 'light';
}

export function useTheme() {
  const [theme, setThemeState] = useState<Theme>(current);

  const setTheme = useCallback((t: Theme) => {
    document.documentElement.classList.toggle('dark', t === 'dark');
    try {
      localStorage.setItem('abhi-theme', t);
    } catch {
      /* storage may be unavailable (private mode) */
    }
    const meta = document.querySelector('meta[name="theme-color"]');
    meta?.setAttribute('content', t === 'dark' ? '#070816' : '#f3f5fc');
    setThemeState(t);
  }, []);

  useEffect(() => {
    setThemeState(current());
  }, []);

  return { theme, setTheme, toggle: () => setTheme(theme === 'dark' ? 'light' : 'dark') };
}
