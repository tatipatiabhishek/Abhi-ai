import { useCallback, useRef, useState } from 'react';
import { api, streamChat } from '../lib/api';
import type { Msg, PendingFile } from '../lib/types';
import { useProfile } from './useProfile';

const uid = () => `tmp-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

interface Options {
  voiceMode?: boolean;
  /** Called when a reply has fully arrived (used by voice mode to speak it). */
  onReply?: (text: string) => void;
  /** Called after any exchange so the sidebar can refresh. */
  onChanged?: () => void;
}

export function useChat(options: Options = {}) {
  const { profile } = useProfile();
  const [messages, setMessages] = useState<Msg[]>([]);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const convRef = useRef<string | null>(null);
  const optsRef = useRef(options);
  optsRef.current = options;

  const reset = useCallback(() => {
    abortRef.current?.abort();
    convRef.current = null;
    setConversationId(null);
    setMessages([]);
    setError(null);
    setSending(false);
  }, []);

  const load = useCallback(async (id: string) => {
    abortRef.current?.abort();
    setLoadingHistory(true);
    setError(null);
    setSending(false);
    try {
      const res = await api<{ messages: Msg[] }>(`/conversations/${id}`);
      convRef.current = id;
      setConversationId(id);
      setMessages(res.messages);
    } catch (e) {
      setError((e as Error).message);
      setMessages([]);
    } finally {
      setLoadingHistory(false);
    }
  }, []);

  const stop = useCallback(() => {
    abortRef.current?.abort();
  }, []);

  const send = useCallback(
    async (text: string, files: PendingFile[] = []) => {
      const message = text.trim();
      if (!message || sending) return;
      setError(null);
      setSending(true);

      const userMsg: Msg = {
        id: uid(),
        role: 'user',
        content: message,
        attachments: files.map((f) => ({ name: f.name, mimeType: f.mimeType })),
      };
      const botId = uid();
      setMessages((m) => [...m, userMsg, { id: botId, role: 'model', content: '', pending: true }]);

      const controller = new AbortController();
      abortRef.current = controller;
      let reply = '';

      try {
        await streamChat(
          {
            conversationId: convRef.current ?? undefined,
            message,
            language: profile.language,
            model: profile.model,
            webSearch: profile.web_search,
            voiceMode: optsRef.current.voiceMode,
            attachments: files.map(({ name, mimeType, data }) => ({ name, mimeType, data })),
          },
          {
            onStart: (id) => {
              convRef.current = id;
              setConversationId(id);
            },
            onDelta: (t) => {
              reply += t;
              setMessages((m) => m.map((x) => (x.id === botId ? { ...x, content: x.content + t } : x)));
            },
            onDone: ({ messageId, sources }) => {
              setMessages((m) =>
                m.map((x) => (x.id === botId ? { ...x, id: messageId ?? x.id, pending: false, sources } : x))
              );
            },
          },
          controller.signal
        );
        if (reply) optsRef.current.onReply?.(reply);
      } catch (e) {
        if ((e as Error).name === 'AbortError') {
          setMessages((m) => m.map((x) => (x.id === botId ? { ...x, pending: false } : x)).filter((x) => x.content || x.role === 'user'));
        } else {
          const msg = (e as Error).message || 'Something went wrong.';
          setError(msg);
          setMessages((m) => m.filter((x) => !(x.id === botId && !x.content)).map((x) => (x.id === botId ? { ...x, pending: false } : x)));
        }
      } finally {
        setMessages((m) => m.map((x) => (x.id === botId ? { ...x, pending: false } : x)));
        setSending(false);
        abortRef.current = null;
        optsRef.current.onChanged?.();
      }
    },
    [profile.language, profile.model, profile.web_search, sending]
  );

  return { messages, conversationId, sending, loadingHistory, error, setError, send, stop, reset, load };
}
