import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { History, ImageIcon, MessageSquare, Mic, Moon, Plus, Settings, Sun, User } from 'lucide-react';
import { Logo } from './Logo';
import { ConversationsProvider, useConversations } from '../hooks/useConversations';
import { useAuth } from '../hooks/useAuth';
import { useProfile } from '../hooks/useProfile';
import { useTheme } from '../hooks/useTheme';

const NAV = [
  { to: '/chat', label: 'Chat', icon: MessageSquare },
  { to: '/voice', label: 'Voice', icon: Mic },
  { to: '/image', label: 'Image', icon: ImageIcon },
  { to: '/history', label: 'History', icon: History },
  { to: '/settings', label: 'Settings', icon: Settings },
];

function Sidebar() {
  const { conversations } = useConversations();
  const { user } = useAuth();
  const { profile } = useProfile();
  const { theme, toggle } = useTheme();
  const navigate = useNavigate();
  const name = profile.display_name || user?.email?.split('@')[0] || 'You';

  return (
    <aside className="hidden w-72 shrink-0 flex-col border-r border-line bg-panel/40 p-4 backdrop-blur md:flex">
      <div className="mb-5 flex items-center justify-between">
        <NavLink to="/chat">
          <Logo />
        </NavLink>
        <button onClick={toggle} className="rounded-lg p-2 text-mute hover:bg-panel hover:text-fg" aria-label="Toggle theme">
          {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
        </button>
      </div>

      <button onClick={() => navigate('/chat')} className="btn-primary mb-4 w-full">
        <Plus size={18} /> New chat
      </button>

      <nav className="space-y-1">
        {NAV.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              `flex items-center gap-3 rounded-xl px-3 py-2 text-sm transition ${
                isActive ? 'bg-brand-blue/15 font-medium text-fg' : 'text-mute hover:bg-panel hover:text-fg'
              }`
            }
          >
            <Icon size={18} /> {label}
          </NavLink>
        ))}
      </nav>

      <p className="mb-2 mt-6 px-3 text-xs font-medium uppercase tracking-wider text-mute">Recent</p>
      <div className="-mx-1 flex-1 space-y-0.5 overflow-y-auto px-1">
        {conversations.slice(0, 20).map((c) => (
          <NavLink
            key={c.id}
            to={`/chat/${c.id}`}
            className={({ isActive }) =>
              `block truncate rounded-lg px-3 py-1.5 text-sm ${isActive ? 'bg-panel text-fg' : 'text-mute hover:bg-panel hover:text-fg'}`
            }
            title={c.title}
          >
            {c.title}
          </NavLink>
        ))}
        {conversations.length === 0 && <p className="px-3 text-sm text-mute/80">No conversations yet.</p>}
      </div>

      <NavLink to="/profile" className="mt-3 flex items-center gap-3 rounded-xl border border-line bg-panel/60 p-2.5 hover:bg-panel">
        <span className="grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-brand-blue to-brand-purple text-sm font-semibold text-white">
          {name.charAt(0).toUpperCase()}
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-sm font-medium">{name}</span>
          <span className="block truncate text-xs text-mute">{user?.email}</span>
        </span>
      </NavLink>
    </aside>
  );
}

function MobileHeader() {
  const { theme, toggle } = useTheme();
  const navigate = useNavigate();
  return (
    <header className="flex items-center justify-between border-b border-line bg-panel/60 px-4 py-2.5 backdrop-blur md:hidden">
      <NavLink to="/chat">
        <Logo size={30} />
      </NavLink>
      <div className="flex items-center gap-1">
        <button onClick={() => navigate('/chat')} className="rounded-lg p-2 text-mute hover:text-fg" aria-label="New chat">
          <Plus size={20} />
        </button>
        <button onClick={toggle} className="rounded-lg p-2 text-mute hover:text-fg" aria-label="Toggle theme">
          {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
        </button>
        <NavLink to="/profile" className="rounded-lg p-2 text-mute hover:text-fg" aria-label="Profile">
          <User size={20} />
        </NavLink>
      </div>
    </header>
  );
}

function BottomNav() {
  return (
    <nav className="flex border-t border-line bg-panel/80 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden">
      {NAV.map(({ to, label, icon: Icon }) => (
        <NavLink
          key={to}
          to={to}
          className={({ isActive }) =>
            `flex flex-1 flex-col items-center gap-0.5 py-2 text-[11px] ${isActive ? 'text-brand-blue' : 'text-mute'}`
          }
        >
          <Icon size={20} /> {label}
        </NavLink>
      ))}
    </nav>
  );
}

export function AppShell() {
  return (
    <ConversationsProvider>
      <div className="glow-bg flex h-full">
        <Sidebar />
        <div className="flex min-w-0 flex-1 flex-col">
          <MobileHeader />
          <main className="min-h-0 flex-1 overflow-hidden">
            <Outlet />
          </main>
          <BottomNav />
        </div>
      </div>
    </ConversationsProvider>
  );
}
