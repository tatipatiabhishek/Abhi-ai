import { Children, isValidElement, ReactNode, useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Brain, Check, Copy, FileText, Globe, Image as ImageIcon, Volume2, VolumeX } from 'lucide-react';
import type { Msg } from '../lib/types';
import { LogoMark } from './Logo';

function CodeBlock({ children }: { children?: ReactNode }) {
  const [copied, setCopied] = useState(false);
  const child = Children.toArray(children)[0];
  let lang = '';
  let code = '';
  if (isValidElement(child)) {
    const props = child.props as { className?: string; children?: ReactNode };
    lang = /language-(\w+)/.exec(props.className || '')?.[1] ?? '';
    code = String(props.children ?? '').replace(/\n$/, '');
  }
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* clipboard blocked */
    }
  };
  return (
    <div className="overflow-hidden rounded-xl border border-line bg-black/40 text-left">
      <div className="flex items-center justify-between border-b border-line px-3 py-1.5 text-xs text-mute">
        <span>{lang || 'code'}</span>
        <button onClick={copy} className="inline-flex items-center gap-1 hover:text-fg">
          {copied ? <Check size={13} /> : <Copy size={13} />} {copied ? 'Copied' : 'Copy'}
        </button>
      </div>
      <pre className="overflow-x-auto p-3 text-[13px] leading-relaxed text-slate-100">
        <code>{code}</code>
      </pre>
    </div>
  );
}

export function Markdown({ text }: { text: string }) {
  return (
    <div className="prose-chat">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          pre: ({ children }) => <CodeBlock>{children}</CodeBlock>,
          table: ({ children }) => (
            <div className="table-wrap">
              <table>{children}</table>
            </div>
          ),
          a: ({ href, children }) => (
            <a href={href} target="_blank" rel="noreferrer noopener">
              {children}
            </a>
          ),
        }}
      >
        {text}
      </ReactMarkdown>
    </div>
  );
}

interface Props {
  msg: Msg;
  speaking?: boolean;
  onSpeak?: (msg: Msg) => void;
  onRemember?: (msg: Msg) => void;
}

export function MessageBubble({ msg, speaking, onSpeak, onRemember }: Props) {
  const [copied, setCopied] = useState(false);
  const isUser = msg.role === 'user';

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(msg.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* clipboard blocked */
    }
  };

  if (isUser) {
    return (
      <div className="flex animate-fadeUp justify-end">
        <div className="group max-w-[88%] md:max-w-[75%]">
          {!!msg.attachments?.length && (
            <div className="mb-1.5 flex flex-wrap justify-end gap-1.5">
              {msg.attachments.map((a, i) => (
                <span key={i} className="inline-flex items-center gap-1.5 rounded-lg border border-line bg-panel/70 px-2 py-1 text-xs text-mute">
                  {a.mimeType.startsWith('image/') ? <ImageIcon size={13} /> : <FileText size={13} />}
                  <span className="max-w-[140px] truncate">{a.name}</span>
                </span>
              ))}
            </div>
          )}
          <div className="whitespace-pre-wrap rounded-2xl rounded-tr-md bg-gradient-to-br from-brand-blue to-brand-purple px-4 py-2.5 text-[15px] text-white shadow-lg shadow-brand-purple/20">
            {msg.content}
          </div>
          {onRemember && !msg.id.startsWith('tmp-') && (
            <div className="mt-1 flex justify-end opacity-0 transition group-hover:opacity-100 focus-within:opacity-100 max-md:opacity-100">
              <button onClick={() => onRemember(msg)} className="inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 text-xs text-mute hover:bg-panel hover:text-fg">
                <Brain size={13} /> Remember this
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="flex animate-fadeUp gap-3">
      <div className="mt-0.5 shrink-0">
        <LogoMark size={30} />
      </div>
      <div className="min-w-0 flex-1">
        {msg.pending && !msg.content ? (
          <div className="flex gap-1 py-3" aria-label="ABHI AI is thinking">
            {[0, 1, 2].map((i) => (
              <span key={i} className="h-2 w-2 animate-dots rounded-full bg-brand-blue" style={{ animationDelay: `${i * 0.2}s` }} />
            ))}
          </div>
        ) : (
          <Markdown text={msg.content} />
        )}

        {!!msg.sources?.length && (
          <div className="mt-3 flex flex-wrap items-center gap-1.5">
            <span className="inline-flex items-center gap-1 text-xs text-mute">
              <Globe size={13} /> Sources
            </span>
            {msg.sources.map((s) => (
              <a
                key={s.uri}
                href={s.uri}
                target="_blank"
                rel="noreferrer noopener"
                className="max-w-[200px] truncate rounded-full border border-line bg-panel/70 px-2.5 py-0.5 text-xs text-mute hover:text-fg"
                title={s.uri}
              >
                {s.title}
              </a>
            ))}
          </div>
        )}

        {!msg.pending && msg.content && (
          <div className="mt-2 flex items-center gap-1 text-mute">
            <button onClick={copy} className="rounded-md p-1.5 hover:bg-panel hover:text-fg" aria-label="Copy answer" title="Copy">
              {copied ? <Check size={15} /> : <Copy size={15} />}
            </button>
            {onSpeak && (
              <button
                onClick={() => onSpeak(msg)}
                className="rounded-md p-1.5 hover:bg-panel hover:text-fg"
                aria-label={speaking ? 'Stop reading' : 'Read aloud'}
                title={speaking ? 'Stop' : 'Read aloud'}
              >
                {speaking ? <VolumeX size={15} /> : <Volume2 size={15} />}
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
