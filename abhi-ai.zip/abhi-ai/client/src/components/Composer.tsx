import { KeyboardEvent, useEffect, useRef, useState } from 'react';
import { ArrowUp, FileText, Mic, Paperclip, Square, X } from 'lucide-react';
import { ACCEPT, filesToPending } from '../lib/files';
import { listen, Listener, sttSupported } from '../lib/speech';
import type { Lang, PendingFile } from '../lib/types';

interface Props {
  sending: boolean;
  lang: Lang;
  placeholder?: string;
  onSend: (text: string, files: PendingFile[]) => void;
  onStop: () => void;
  allowFiles?: boolean;
}

export function Composer({ sending, lang, placeholder = 'Message ABHI AI…', onSend, onStop, allowFiles = true }: Props) {
  const [text, setText] = useState('');
  const [files, setFiles] = useState<PendingFile[]>([]);
  const [listening, setListening] = useState(false);
  const [note, setNote] = useState<string | null>(null);
  const areaRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const listenerRef = useRef<Listener | null>(null);

  // Auto-grow the textarea
  useEffect(() => {
    const el = areaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 180)}px`;
  }, [text]);

  useEffect(() => () => listenerRef.current?.stop(), []);

  const submit = () => {
    if (!text.trim() || sending) return;
    listenerRef.current?.stop();
    onSend(text, files);
    setText('');
    setFiles([]);
    setNote(null);
  };

  const onKey = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
      e.preventDefault();
      submit();
    }
  };

  const pickFiles = async (list: FileList | null) => {
    if (!list?.length) return;
    try {
      const added = await filesToPending(Array.from(list), files);
      setFiles((f) => [...f, ...added]);
      setNote(null);
    } catch (e) {
      setNote((e as Error).message);
    }
    if (fileRef.current) fileRef.current.value = '';
  };

  const toggleMic = () => {
    if (listening) {
      listenerRef.current?.stop();
      return;
    }
    const base = text ? text.trimEnd() + ' ' : '';
    setNote(null);
    listenerRef.current = listen(lang, {
      onResult: (t) => setText(base + t),
      onEnd: () => setListening(false),
      onError: (m) => {
        setNote(m);
        setListening(false);
      },
    });
    if (listenerRef.current) setListening(true);
  };

  return (
    <div className="mx-auto w-full max-w-3xl px-3 safe-bottom">
      {note && <p className="mb-2 rounded-lg bg-amber-500/10 px-3 py-1.5 text-xs text-amber-600 dark:text-amber-400">{note}</p>}
      <div className="card p-2 shadow-xl shadow-black/10 focus-within:border-brand-blue/60">
        {files.length > 0 && (
          <div className="flex flex-wrap gap-2 px-1 pb-2">
            {files.map((f, i) => (
              <div key={i} className="relative flex items-center gap-2 rounded-xl border border-line bg-bg/50 p-1.5 pr-3 text-xs">
                {f.previewUrl ? (
                  <img src={f.previewUrl} alt="" className="h-10 w-10 rounded-lg object-cover" />
                ) : (
                  <span className="grid h-10 w-10 place-items-center rounded-lg bg-brand-purple/15 text-brand-purple">
                    <FileText size={18} />
                  </span>
                )}
                <span className="max-w-[120px] truncate">{f.name}</span>
                <button
                  onClick={() => setFiles((list) => list.filter((_, j) => j !== i))}
                  className="absolute -right-1.5 -top-1.5 grid h-5 w-5 place-items-center rounded-full border border-line bg-panel text-mute hover:text-fg"
                  aria-label={`Remove ${f.name}`}
                >
                  <X size={11} />
                </button>
              </div>
            ))}
          </div>
        )}

        <div className="flex items-end gap-1.5">
          {allowFiles && (
            <>
              <input ref={fileRef} type="file" accept={ACCEPT} multiple hidden onChange={(e) => pickFiles(e.target.files)} />
              <button onClick={() => fileRef.current?.click()} className="rounded-xl p-2.5 text-mute hover:bg-bg/60 hover:text-fg" aria-label="Attach a file" title="Attach image, PDF or TXT">
                <Paperclip size={20} />
              </button>
            </>
          )}
          <textarea
            ref={areaRef}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={onKey}
            rows={1}
            maxLength={8000}
            placeholder={listening ? 'Listening…' : placeholder}
            className="max-h-[180px] min-h-[44px] flex-1 resize-none bg-transparent px-1 py-2.5 text-[15px] outline-none placeholder:text-mute/70"
          />
          {sttSupported && (
            <button
              onClick={toggleMic}
              className={`rounded-xl p-2.5 transition ${listening ? 'animate-pulse bg-red-500/15 text-red-500' : 'text-mute hover:bg-bg/60 hover:text-fg'}`}
              aria-label={listening ? 'Stop dictation' : 'Dictate with your voice'}
              title="Voice typing"
            >
              <Mic size={20} />
            </button>
          )}
          {sending ? (
            <button onClick={onStop} className="rounded-xl bg-fg p-2.5 text-bg" aria-label="Stop generating" title="Stop">
              <Square size={18} fill="currentColor" />
            </button>
          ) : (
            <button
              onClick={submit}
              disabled={!text.trim()}
              className="rounded-xl bg-gradient-to-br from-brand-blue to-brand-purple p-2.5 text-white transition enabled:hover:brightness-110 disabled:opacity-40"
              aria-label="Send message"
            >
              <ArrowUp size={20} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
