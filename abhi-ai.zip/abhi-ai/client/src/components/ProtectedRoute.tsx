import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { ProfileProvider } from '../hooks/useProfile';

export function FullScreenSpinner() {
  return (
    <div className="grid h-full place-items-center">
      <div className="h-10 w-10 animate-spin rounded-full border-4 border-line border-t-brand-blue" role="status" aria-label="Loading" />
    </div>
  );
}

/** Only signed-in users can see the app. Wraps routes with the profile provider. */
export function ProtectedRoute() {
  const { user, loading } = useAuth();
  const location = useLocation();
  if (loading) return <FullScreenSpinner />;
  if (!user) return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  return (
    <ProfileProvider>
      <Outlet />
    </ProfileProvider>
  );
}
