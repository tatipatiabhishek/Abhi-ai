export type OrbState = 'idle' | 'listening' | 'thinking' | 'speaking';

/** Animated assistant orb. Its motion reflects what the assistant is doing. */
export function Orb({ state = 'idle', size = 180, onClick, label }: { state?: OrbState; size?: number; onClick?: () => void; label?: string }) {
  const active = state === 'listening' || state === 'speaking';
  const Tag = onClick ? 'button' : 'div';
  return (
    <Tag
      onClick={onClick}
      aria-label={label}
      className={`relative grid place-items-center rounded-full outline-none ${onClick ? 'cursor-pointer focus-visible:ring-4 focus-visible:ring-brand-blue/40' : ''}`}
      style={{ width: size, height: size }}
    >
      {active && (
        <>
          <span className="absolute inset-0 animate-ring rounded-full bg-brand-blue/40" />
          <span className="absolute inset-0 animate-ring rounded-full bg-brand-purple/40 [animation-delay:0.7s]" />
        </>
      )}
      <span
        className={`absolute inset-0 rounded-full bg-gradient-to-br from-brand-cyan via-brand-blue to-brand-purple shadow-[0_0_80px_-10px] shadow-brand-purple/60 ${
          state === 'thinking' ? 'animate-spin [animation-duration:2.5s]' : 'animate-float'
        }`}
      />
      <span className="absolute inset-[12%] rounded-full bg-gradient-to-tr from-white/30 to-transparent blur-sm" />
      <span className="relative flex items-end gap-1" style={{ height: size * 0.28 }} aria-hidden="true">
        {[0.5, 0.9, 0.6, 1, 0.55].map((h, i) => (
          <span
            key={i}
            className={`w-1.5 rounded-full bg-white/90 ${active ? 'animate-pulse' : ''}`}
            style={{
              height: `${(active ? h : 0.35) * 100}%`,
              animationDelay: `${i * 120}ms`,
              transition: 'height 0.3s',
            }}
          />
        ))}
      </span>
    </Tag>
  );
}
