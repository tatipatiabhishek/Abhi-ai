import { Link } from 'react-router-dom';
import { ArrowRight, Brain, Code2, Globe, History, ImageIcon, Languages, Mic, Moon, Shield, Sun } from 'lucide-react';
import { Logo } from '../components/Logo';
import { Orb } from '../components/Orb';
import { useAuth } from '../hooks/useAuth';
import { useTheme } from '../hooks/useTheme';

const FEATURES = [
  { icon: Mic, title: 'Talk to it', text: 'Speak naturally and hear answers read back in English, Telugu or Hindi.' },
  { icon: ImageIcon, title: 'Understands images', text: 'Upload photos, screenshots or PDFs and ask questions about them.' },
  { icon: Globe, title: 'Searches the web', text: 'Gets current information and shows the sources it used.' },
  { icon: Code2, title: 'Codes with you', text: 'Generate, explain and debug code with one-tap copy.' },
  { icon: Brain, title: 'Remembers what you approve', text: 'Your preferences are saved only when you say so, and you can delete them anytime.' },
  { icon: History, title: 'Saves your chats', text: 'Search, rename and revisit past conversations on any device.' },
  { icon: Languages, title: 'Multilingual', text: 'Switch between English, తెలుగు and हिन्दी whenever you like.' },
  { icon: Shield, title: 'Private by design', text: 'API keys stay on the server and every chat is locked to your account.' },
];

export default function Landing() {
  const { user } = useAuth();
  const { theme, toggle } = useTheme();
  const cta = user ? '/chat' : '/register';

  return (
    <div className="glow-bg min-h-full overflow-y-auto">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
        <Logo />
        <div className="flex items-center gap-2">
          <button onClick={toggle} className="rounded-lg p-2 text-mute hover:text-fg" aria-label="Toggle theme">
            {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
          </button>
          {user ? (
            <Link to="/chat" className="btn-primary">Open ABHI AI</Link>
          ) : (
            <>
              <Link to="/login" className="btn-ghost hidden sm:inline-flex">Sign in</Link>
              <Link to="/register" className="btn-primary">Get started</Link>
            </>
          )}
        </div>
      </header>

      <main>
        <section className="mx-auto flex max-w-4xl flex-col items-center px-4 pb-16 pt-10 text-center md:pt-16">
          <Orb size={150} />
          <h1 className="mt-8 font-display text-4xl font-bold tracking-tight sm:text-6xl">
            Your personal <span className="gradient-text">AI assistant</span>
          </h1>
          <p className="mt-5 max-w-xl text-lg text-mute">
            Chat, talk, share images and search the web, in English, తెలుగు and हिन्दी. ABHI AI helps with everyday questions, writing, learning and code.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link to={cta} className="btn-primary px-6 py-3 text-base">
              {user ? 'Open ABHI AI' : 'Start for free'} <ArrowRight size={18} />
            </Link>
            {!user && (
              <Link to="/login" className="btn-ghost px-6 py-3 text-base">
                I already have an account
              </Link>
            )}
          </div>
        </section>

        <section className="mx-auto grid max-w-6xl gap-3 px-4 pb-20 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map(({ icon: Icon, title, text }) => (
            <div key={title} className="card p-5 transition hover:-translate-y-0.5 hover:border-brand-blue/50">
              <span className="mb-3 grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-brand-blue/20 to-brand-purple/20 text-brand-blue">
                <Icon size={20} />
              </span>
              <h2 className="font-display text-base font-semibold">{title}</h2>
              <p className="mt-1 text-sm text-mute">{text}</p>
            </div>
          ))}
        </section>
      </main>

      <footer className="border-t border-line px-4 py-6 text-center text-sm text-mute">© {new Date().getFullYear()} ABHI AI. Install it on Android from your browser menu: “Add to Home screen”.</footer>
    </div>
  );
}
