import { FormEvent, useState } from 'react';
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { AlertTriangle, Loader2 } from 'lucide-react';
import { Logo } from '../components/Logo';
import { FullScreenSpinner } from '../components/ProtectedRoute';
import { useAuth } from '../hooks/useAuth';
import { supabase, supabaseConfigured } from '../lib/supabase';

export default function Auth({ mode }: { mode: 'login' | 'register' }) {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = (location.state as { from?: string } | null)?.from || '/chat';

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  if (loading) return <FullScreenSpinner />;
  if (user) return <Navigate to={from} replace />;

  const isRegister = mode === 'register';

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setInfo(null);
    if (!supabaseConfigured) return setError('Supabase is not configured yet. Add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to your .env file.');
    if (isRegister && password.length < 8) return setError('Please use a password with at least 8 characters.');

    setBusy(true);
    try {
      if (isRegister) {
        const { data, error: err } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: { data: { display_name: name.trim() || undefined } },
        });
        if (err) throw err;
        if (!data.session) {
          setInfo('Account created! Check your email for a confirmation link, then sign in.');
        } else {
          navigate('/chat', { replace: true });
        }
      } else {
        const { error: err } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (err) throw err;
        navigate(from, { replace: true });
      }
    } catch (err) {
      const msg = (err as Error).message || 'Something went wrong.';
      setError(/invalid login/i.test(msg) ? 'Incorrect email or password.' : /email not confirmed/i.test(msg) ? 'Please confirm your email first (check your inbox).' : msg);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="glow-bg grid min-h-full place-items-center px-4 py-10">
      <div className="w-full max-w-sm">
        <Link to="/" className="mb-6 flex justify-center">
          <Logo size={42} />
        </Link>

        <div className="card p-6 shadow-2xl shadow-black/20">
          <h1 className="font-display text-2xl font-semibold">{isRegister ? 'Create your account' : 'Welcome back'}</h1>
          <p className="mb-5 mt-1 text-sm text-mute">{isRegister ? 'Start chatting with ABHI AI in seconds.' : 'Sign in to continue to ABHI AI.'}</p>

          {!supabaseConfigured && (
            <div className="mb-4 flex gap-2 rounded-xl border border-amber-500/30 bg-amber-500/10 p-3 text-xs text-amber-600 dark:text-amber-400">
              <AlertTriangle size={16} className="shrink-0" />
              <span>Setup needed: add your Supabase URL and anon key to <code>.env</code> and restart. See the README.</span>
            </div>
          )}

          <form onSubmit={submit} className="space-y-3">
            {isRegister && (
              <div>
                <label htmlFor="name" className="mb-1 block text-sm font-medium">Name</label>
                <input id="name" value={name} onChange={(e) => setName(e.target.value)} maxLength={60} autoComplete="name" placeholder="Abhi" className="input" />
              </div>
            )}
            <div>
              <label htmlFor="email" className="mb-1 block text-sm font-medium">Email</label>
              <input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" placeholder="you@example.com" className="input" />
            </div>
            <div>
              <label htmlFor="password" className="mb-1 block text-sm font-medium">Password</label>
              <input
                id="password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete={isRegister ? 'new-password' : 'current-password'}
                minLength={isRegister ? 8 : undefined}
                placeholder={isRegister ? 'At least 8 characters' : 'Your password'}
                className="input"
              />
            </div>

            {error && <p className="rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-500" role="alert">{error}</p>}
            {info && <p className="rounded-lg bg-green-500/10 px-3 py-2 text-sm text-green-600 dark:text-green-400" role="status">{info}</p>}

            <button type="submit" disabled={busy} className="btn-primary w-full">
              {busy && <Loader2 size={16} className="animate-spin" />}
              {isRegister ? 'Create account' : 'Sign in'}
            </button>
          </form>
        </div>

        <p className="mt-5 text-center text-sm text-mute">
          {isRegister ? 'Already have an account?' : 'New to ABHI AI?'}{' '}
          <Link to={isRegister ? '/login' : '/register'} className="font-medium text-brand-blue hover:underline">
            {isRegister ? 'Sign in' : 'Create an account'}
          </Link>
        </p>
      </div>
    </div>
  );
}
