import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Brain, LogOut, MessageSquare, Settings } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useConversations } from '../hooks/useConversations';
import { useProfile } from '../hooks/useProfile';
import { useToast } from '../hooks/useToast';
import { api } from '../lib/api';
import { LANGUAGES } from '../lib/types';

export default function ProfilePage() {
  const { user, signOut } = useAuth();
  const { profile, update } = useProfile();
  const { conversations } = useConversations();
  const toast = useToast();
  const [name, setName] = useState(profile.display_name ?? '');
  const [memoryCount, setMemoryCount] = useState<number | null>(null);

  useEffect(() => setName(profile.display_name ?? ''), [profile.display_name]);
  useEffect(() => {
    api<{ memories: unknown[] }>('/memories').then((r) => setMemoryCount(r.memories.length)).catch(() => {});
  }, []);

  const display = profile.display_name || user?.email?.split('@')[0] || 'You';
  const joined = user?.created_at ? new Date(user.created_at).toLocaleDateString([], { month: 'long', year: 'numeric' }) : '';
  const lang = LANGUAGES.find((l) => l.code === profile.language);

  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto max-w-xl space-y-4 p-4">
        <div className="card flex flex-col items-center p-6 text-center">
          <span className="grid h-20 w-20 place-items-center rounded-full bg-gradient-to-br from-brand-blue to-brand-purple font-display text-3xl font-semibold text-white shadow-lg shadow-brand-purple/30">
            {display.charAt(0).toUpperCase()}
          </span>
          <h1 className="mt-3 font-display text-2xl font-semibold">{display}</h1>
          <p className="text-sm text-mute">{user?.email}</p>
          {joined && <p className="mt-1 text-xs text-mute">Member since {joined}</p>}
        </div>

        <div className="grid grid-cols-3 gap-2.5 text-center">
          <div className="card p-3">
            <MessageSquare size={18} className="mx-auto mb-1 text-brand-blue" />
            <p className="font-display text-xl font-semibold">{conversations.length}</p>
            <p className="text-xs text-mute">Chats</p>
          </div>
          <div className="card p-3">
            <Brain size={18} className="mx-auto mb-1 text-brand-purple" />
            <p className="font-display text-xl font-semibold">{memoryCount ?? '–'}</p>
            <p className="text-xs text-mute">Memories</p>
          </div>
          <div className="card p-3">
            <span className="mx-auto mb-1 block text-lg leading-[18px]">🌐</span>
            <p className="font-display text-xl font-semibold">{lang?.native}</p>
            <p className="text-xs text-mute">Language</p>
          </div>
        </div>

        <div className="card p-4">
          <label className="mb-1 block text-sm font-medium" htmlFor="display-name">
            Display name
          </label>
          <div className="flex gap-2">
            <input id="display-name" value={name} onChange={(e) => setName(e.target.value)} maxLength={60} className="input" />
            <button
              onClick={() =>
                update({ display_name: name.trim() })
                  .then(() => toast.show('Profile updated'))
                  .catch((e) => toast.show(e.message))
              }
              className="btn-primary shrink-0"
            >
              Save
            </button>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <Link to="/settings" className="btn-ghost">
            <Settings size={16} /> Settings
          </Link>
          <button onClick={() => signOut()} className="btn-ghost">
            <LogOut size={16} /> Sign out
          </button>
        </div>
      </div>
      {toast.node}
    </div>
  );
}
