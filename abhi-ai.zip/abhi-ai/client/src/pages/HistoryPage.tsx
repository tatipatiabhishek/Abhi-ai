import { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Check, Pencil, Search, Trash2, X } from 'lucide-react';
import { useConversations } from '../hooks/useConversations';
import { useToast } from '../hooks/useToast';

function formatDate(iso: string) {
  const d = new Date(iso);
  const today = new Date();
  const sameDay = d.toDateString() === today.toDateString();
  return sameDay ? d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : d.toLocaleDateString([], { day: 'numeric', month: 'short', year: 'numeric' });
}

export default function HistoryPage() {
  const { conversations, loading, rename, remove, removeAll } = useConversations();
  const navigate = useNavigate();
  const toast = useToast();
  const [query, setQuery] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState('');

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return q ? conversations.filter((c) => c.title.toLowerCase().includes(q)) : conversations;
  }, [conversations, query]);

  const saveRename = async (id: string) => {
    const title = draft.trim();
    if (!title) return setEditingId(null);
    try {
      await rename(id, title);
    } catch (e) {
      toast.show((e as Error).message);
    }
    setEditingId(null);
  };

  const del = async (id: string, title: string) => {
    if (!window.confirm(`Delete "${title}"? This cannot be undone.`)) return;
    try {
      await remove(id);
      toast.show('Conversation deleted');
    } catch (e) {
      toast.show((e as Error).message);
    }
  };

  const delAll = async () => {
    if (!window.confirm('Delete ALL conversations? This cannot be undone.')) return;
    try {
      await removeAll();
      toast.show('All conversations deleted');
    } catch (e) {
      toast.show((e as Error).message);
    }
  };

  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto max-w-3xl p-4">
        <div className="mb-4 flex items-end justify-between gap-3">
          <div>
            <h1 className="font-display text-2xl font-semibold">Chat history</h1>
            <p className="text-sm text-mute">{conversations.length} saved conversation{conversations.length === 1 ? '' : 's'}</p>
          </div>
          {conversations.length > 0 && (
            <button onClick={delAll} className="btn-danger px-3 py-2 text-xs">
              <Trash2 size={14} /> Delete all
            </button>
          )}
        </div>

        <div className="relative mb-4">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-mute" />
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search conversations…" className="input pl-10" aria-label="Search conversations" />
        </div>

        {loading && conversations.length === 0 && <p className="py-10 text-center text-sm text-mute">Loading…</p>}
        {!loading && filtered.length === 0 && (
          <div className="card p-10 text-center text-sm text-mute">
            {query ? 'No conversations match your search.' : (
              <>
                Nothing here yet. <Link to="/chat" className="text-brand-blue underline">Start a chat</Link>
              </>
            )}
          </div>
        )}

        <ul className="space-y-2">
          {filtered.map((c) => (
            <li key={c.id} className="card flex items-center gap-2 p-2.5 pl-4 transition hover:border-brand-blue/40">
              {editingId === c.id ? (
                <>
                  <input
                    autoFocus
                    value={draft}
                    maxLength={100}
                    onChange={(e) => setDraft(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') saveRename(c.id);
                      if (e.key === 'Escape') setEditingId(null);
                    }}
                    className="input py-1.5"
                    aria-label="Conversation title"
                  />
                  <button onClick={() => saveRename(c.id)} className="rounded-lg p-2 text-green-500 hover:bg-bg/60" aria-label="Save title">
                    <Check size={18} />
                  </button>
                  <button onClick={() => setEditingId(null)} className="rounded-lg p-2 text-mute hover:bg-bg/60" aria-label="Cancel">
                    <X size={18} />
                  </button>
                </>
              ) : (
                <>
                  <button onClick={() => navigate(`/chat/${c.id}`)} className="min-w-0 flex-1 py-1 text-left">
                    <span className="block truncate font-medium">{c.title}</span>
                    <span className="block text-xs text-mute">{formatDate(c.updated_at)}</span>
                  </button>
                  <button
                    onClick={() => {
                      setEditingId(c.id);
                      setDraft(c.title);
                    }}
                    className="rounded-lg p-2 text-mute hover:bg-bg/60 hover:text-fg"
                    aria-label={`Rename ${c.title}`}
                  >
                    <Pencil size={16} />
                  </button>
                  <button onClick={() => del(c.id, c.title)} className="rounded-lg p-2 text-mute hover:bg-red-500/10 hover:text-red-500" aria-label={`Delete ${c.title}`}>
                    <Trash2 size={16} />
                  </button>
                </>
              )}
            </li>
          ))}
        </ul>
      </div>
      {toast.node}
    </div>
  );
}
