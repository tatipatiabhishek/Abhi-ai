import { ReactNode, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Brain, LogOut, Play, Plus, Trash2 } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useConversations } from '../hooks/useConversations';
import { useProfile } from '../hooks/useProfile';
import { useTheme } from '../hooks/useTheme';
import { useToast } from '../hooks/useToast';
import { api } from '../lib/api';
import { speak, stopSpeaking, ttsSupported } from '../lib/speech';
import { LANGUAGES, Memory } from '../lib/types';

function Section({ title, description, children }: { title: string; description?: string; children: ReactNode }) {
  return (
    <section className="card p-4 md:p-5">
      <h2 className="font-display text-lg font-semibold">{title}</h2>
      {description && <p className="mb-3 text-sm text-mute">{description}</p>}
      <div className={description ? '' : 'mt-3'}>{children}</div>
    </section>
  );
}

function Toggle({ checked, onChange, label, hint }: { checked: boolean; onChange: (v: boolean) => void; label: string; hint?: string }) {
  return (
    <label className="flex cursor-pointer items-center justify-between gap-4 py-2">
      <span>
        <span className="block text-sm font-medium">{label}</span>
        {hint && <span className="block text-xs text-mute">{hint}</span>}
      </span>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={`relative h-6 w-11 shrink-0 rounded-full transition ${checked ? 'bg-gradient-to-r from-brand-blue to-brand-purple' : 'bg-line'}`}
      >
        <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${checked ? 'left-[22px]' : 'left-0.5'}`} />
      </button>
    </label>
  );
}

export default function SettingsPage() {
  const { signOut } = useAuth();
  const { profile, models, defaultModel, update } = useProfile();
  const { removeAll } = useConversations();
  const { theme, setTheme } = useTheme();
  const toast = useToast();

  const [name, setName] = useState(profile.display_name ?? '');
  const [memories, setMemories] = useState<Memory[]>([]);
  const [newMemory, setNewMemory] = useState('');
  const [health, setHealth] = useState<{ ok: boolean; missing: string[] } | null>(null);

  useEffect(() => setName(profile.display_name ?? ''), [profile.display_name]);

  useEffect(() => {
    api<{ memories: Memory[] }>('/memories').then((r) => setMemories(r.memories)).catch(() => {});
    fetch('/api/health').then((r) => r.json()).then(setHealth).catch(() => setHealth(null));
    return () => stopSpeaking();
  }, []);

  const save = (patch: Parameters<typeof update>[0], message = 'Saved') =>
    update(patch).then(() => toast.show(message)).catch((e) => toast.show(e.message));

  const addMemory = async () => {
    const content = newMemory.trim();
    if (!content) return;
    try {
      const r = await api<{ memory: Memory }>('/memories', { json: { content } });
      setMemories((m) => [r.memory, ...m]);
      setNewMemory('');
    } catch (e) {
      toast.show((e as Error).message);
    }
  };

  const delMemory = async (id: string) => {
    try {
      await api(`/memories/${id}`, { method: 'DELETE' });
      setMemories((m) => m.filter((x) => x.id !== id));
    } catch (e) {
      toast.show((e as Error).message);
    }
  };

  const clearMemories = async () => {
    if (!window.confirm('Forget everything ABHI AI has remembered about you?')) return;
    try {
      await api('/memories', { method: 'DELETE' });
      setMemories([]);
      toast.show('Memory cleared');
    } catch (e) {
      toast.show((e as Error).message);
    }
  };

  const wipeChats = async () => {
    if (!window.confirm('Delete ALL your conversations? This cannot be undone.')) return;
    try {
      await removeAll();
      toast.show('All conversations deleted');
    } catch (e) {
      toast.show((e as Error).message);
    }
  };

  const activeModel = profile.model && models.includes(profile.model) ? profile.model : defaultModel;

  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto max-w-2xl space-y-4 p-4 pb-10">
        <h1 className="font-display text-2xl font-semibold">Settings</h1>

        <Section title="Profile">
          <div className="flex gap-2">
            <input value={name} onChange={(e) => setName(e.target.value)} maxLength={60} placeholder="Your name" className="input" aria-label="Display name" />
            <button onClick={() => save({ display_name: name.trim() })} className="btn-primary shrink-0">
              Save
            </button>
          </div>
          <Link to="/profile" className="mt-2 inline-block text-sm text-brand-blue underline">
            View my profile
          </Link>
        </Section>

        <Section title="Language" description="Used for replies and for voice input and output. You can still write in any of these languages at any time.">
          <div className="grid grid-cols-3 gap-2">
            {LANGUAGES.map((l) => (
              <button
                key={l.code}
                onClick={() => save({ language: l.code })}
                className={`rounded-xl border px-3 py-2.5 text-sm transition ${
                  profile.language === l.code ? 'border-brand-blue bg-brand-blue/15 font-medium' : 'border-line text-mute hover:text-fg'
                }`}
              >
                <span className="block text-base">{l.native}</span>
                <span className="text-xs">{l.label}</span>
              </button>
            ))}
          </div>
        </Section>

        <Section title="Voice" description="Speech uses your browser and device voices. Telugu and Hindi voices depend on what your device has installed.">
          <Toggle checked={profile.voice_enabled} onChange={(v) => save({ voice_enabled: v })} label="Spoken replies in Voice Assistant" hint="ABHI AI reads its answers aloud." />
          <div className="py-2">
            <div className="mb-1 flex justify-between text-sm">
              <span className="font-medium">Speaking speed</span>
              <span className="text-mute">{profile.voice_rate.toFixed(1)}×</span>
            </div>
            <input
              type="range"
              min={0.6}
              max={1.6}
              step={0.1}
              value={profile.voice_rate}
              onChange={(e) => update({ voice_rate: Number(e.target.value) }).catch(() => {})}
              className="w-full accent-brand-purple"
              aria-label="Speaking speed"
            />
          </div>
          {ttsSupported ? (
            <button
              onClick={() =>
                speak(
                  { en: 'Hello! I am ABHI AI, your personal assistant.', te: 'నమస్కారం! నేను అభి ఏఐ, మీ వ్యక్తిగత సహాయకుడిని.', hi: 'नमस्ते! मैं अभि एआई हूँ, आपका निजी सहायक।' }[profile.language],
                  profile.language,
                  profile.voice_rate
                )
              }
              className="btn-ghost mt-1"
            >
              <Play size={15} /> Test voice
            </button>
          ) : (
            <p className="text-sm text-amber-600 dark:text-amber-400">This browser does not support text-to-speech.</p>
          )}
        </Section>

        <Section title="AI" description="Your Gemini API key lives only on the server, never in the app.">
          {models.length > 0 && (
            <label className="mb-2 block">
              <span className="mb-1 block text-sm font-medium">Model</span>
              <select value={activeModel} onChange={(e) => save({ model: e.target.value })} className="input">
                {models.map((m) => (
                  <option key={m} value={m}>
                    {m}
                  </option>
                ))}
              </select>
            </label>
          )}
          <Toggle checked={profile.web_search} onChange={(v) => save({ web_search: v })} label="Web search" hint="Lets ABHI AI look up current information and show sources." />
          {health && (
            <p className={`mt-1 rounded-lg px-3 py-2 text-sm ${health.ok ? 'bg-green-500/10 text-green-600 dark:text-green-400' : 'bg-amber-500/10 text-amber-600 dark:text-amber-400'}`}>
              {health.ok ? 'Server configuration looks good ✓' : `Server is missing: ${health.missing.join(', ')}. See the README.`}
            </p>
          )}
        </Section>

        <Section title="Memory & privacy" description="ABHI AI only remembers things you add here or approve with “Remember this” in chat.">
          <Toggle checked={profile.memory_enabled} onChange={(v) => save({ memory_enabled: v })} label="Use my memories in replies" />
          <div className="mt-2 flex gap-2">
            <input
              value={newMemory}
              onChange={(e) => setNewMemory(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && addMemory()}
              maxLength={500}
              placeholder="e.g. I prefer short answers. I live in Hyderabad."
              className="input"
              aria-label="New memory"
            />
            <button onClick={addMemory} disabled={!newMemory.trim()} className="btn-primary shrink-0" aria-label="Add memory">
              <Plus size={16} />
            </button>
          </div>
          <ul className="mt-3 space-y-1.5">
            {memories.map((m) => (
              <li key={m.id} className="flex items-start gap-2 rounded-xl border border-line bg-bg/40 px-3 py-2 text-sm">
                <Brain size={15} className="mt-0.5 shrink-0 text-brand-purple" />
                <span className="flex-1 break-words">{m.content}</span>
                <button onClick={() => delMemory(m.id)} className="text-mute hover:text-red-500" aria-label="Delete memory">
                  <Trash2 size={15} />
                </button>
              </li>
            ))}
            {memories.length === 0 && <li className="text-sm text-mute">No memories yet.</li>}
          </ul>
          <div className="mt-4 flex flex-wrap gap-2">
            {memories.length > 0 && (
              <button onClick={clearMemories} className="btn-danger px-3 py-2 text-xs">
                Clear all memories
              </button>
            )}
            <button onClick={wipeChats} className="btn-danger px-3 py-2 text-xs">
              Delete all conversations
            </button>
          </div>
        </Section>

        <Section title="Appearance">
          <div className="grid grid-cols-2 gap-2">
            {(['dark', 'light'] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTheme(t)}
                className={`rounded-xl border px-3 py-2.5 text-sm capitalize transition ${theme === t ? 'border-brand-blue bg-brand-blue/15 font-medium' : 'border-line text-mute hover:text-fg'}`}
              >
                {t} mode
              </button>
            ))}
          </div>
        </Section>

        <Section title="Account">
          <button onClick={() => signOut()} className="btn-ghost">
            <LogOut size={16} /> Sign out
          </button>
        </Section>
      </div>
      {toast.node}
    </div>
  );
}
