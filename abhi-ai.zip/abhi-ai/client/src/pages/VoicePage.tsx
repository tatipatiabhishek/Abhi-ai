import { useCallback, useEffect, useRef, useState } from 'react';
import { RotateCcw } from 'lucide-react';
import { Composer } from '../components/Composer';
import { Orb, OrbState } from '../components/Orb';
import { useChat } from '../hooks/useChat';
import { useConversations } from '../hooks/useConversations';
import { useProfile } from '../hooks/useProfile';
import { listen, Listener, speak, stopSpeaking, sttSupported } from '../lib/speech';
import { LANGUAGES } from '../lib/types';

const STATUS: Record<OrbState, string> = {
  idle: 'Tap the orb and start talking',
  listening: 'Listening…',
  thinking: 'Thinking…',
  speaking: 'Speaking… tap to stop',
};

export default function VoicePage() {
  const { profile, update } = useProfile();
  const { refresh } = useConversations();
  const [phase, setPhase] = useState<OrbState>('idle');
  const [interim, setInterim] = useState('');
  const [handsFree, setHandsFree] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const listenerRef = useRef<Listener | null>(null);
  const finalRef = useRef('');
  const handsFreeRef = useRef(handsFree);
  handsFreeRef.current = handsFree;
  const profileRef = useRef(profile);
  profileRef.current = profile;
  const startRef = useRef<() => void>(() => {});
  const sendRef = useRef<(t: string) => void>(() => {});

  const handleReply = useCallback((text: string) => {
    const p = profileRef.current;
    if (!p.voice_enabled) {
      setPhase('idle');
      return;
    }
    setPhase('speaking');
    speak(text, p.language, p.voice_rate).then(() => {
      setPhase((cur) => {
        if (cur !== 'speaking') return cur; // user interrupted
        if (handsFreeRef.current) setTimeout(() => startRef.current(), 250);
        return 'idle';
      });
    });
  }, []);

  const chat = useChat({ voiceMode: true, onReply: handleReply, onChanged: refresh });
  sendRef.current = (t) => {
    chat.send(t);
  };

  // If the request fails (no reply), leave the "thinking" state.
  useEffect(() => {
    if (!chat.sending) setPhase((p) => (p === 'thinking' ? 'idle' : p));
  }, [chat.sending]);

  const startListening = useCallback(() => {
    stopSpeaking();
    setError(null);
    finalRef.current = '';
    setInterim('');
    const l = listen(profileRef.current.language, {
      onResult: (text, final) => {
        setInterim(text);
        if (final) finalRef.current = text;
      },
      onEnd: () => {
        const text = finalRef.current.trim();
        finalRef.current = '';
        setInterim('');
        if (text) {
          setPhase('thinking');
          sendRef.current(text);
        } else {
          setPhase((p) => (p === 'listening' ? 'idle' : p));
        }
      },
      onError: (m) => {
        setError(m);
        setPhase('idle');
      },
    });
    listenerRef.current = l;
    if (l) setPhase('listening');
  }, []);
  startRef.current = startListening;

  useEffect(
    () => () => {
      listenerRef.current?.stop();
      stopSpeaking();
    },
    []
  );

  const onOrb = () => {
    if (phase === 'listening') listenerRef.current?.stop();
    else if (phase === 'speaking') {
      stopSpeaking();
      setPhase('idle');
    } else if (phase === 'thinking') {
      chat.stop();
      setPhase('idle');
    } else startListening();
  };

  const lastUser = [...chat.messages].reverse().find((m) => m.role === 'user');
  const lastBot = [...chat.messages].reverse().find((m) => m.role === 'model');

  return (
    <div className="flex h-full flex-col">
      <div className="flex-1 overflow-y-auto">
        <div className="mx-auto flex min-h-full w-full max-w-2xl flex-col items-center px-4 py-8 text-center">
          {/* Language chips */}
          <div className="flex gap-2">
            {LANGUAGES.map((l) => (
              <button
                key={l.code}
                onClick={() => update({ language: l.code }).catch(() => {})}
                className={`rounded-full border px-3 py-1 text-sm transition ${
                  profile.language === l.code ? 'border-brand-blue bg-brand-blue/15 text-fg' : 'border-line text-mute hover:text-fg'
                }`}
              >
                {l.native}
              </button>
            ))}
          </div>

          <div className="my-10 md:my-14">
            <Orb state={phase} size={200} onClick={onOrb} label="Voice assistant" />
          </div>

          <p className="font-display text-xl font-medium" aria-live="polite">
            {STATUS[phase]}
          </p>
          {interim && <p className="mt-3 text-lg text-brand-blue">“{interim}”</p>}
          {error && (
            <p className="mt-3 rounded-lg bg-amber-500/10 px-3 py-2 text-sm text-amber-600 dark:text-amber-400" role="alert">
              {error}
            </p>
          )}
          {chat.error && (
            <p className="mt-3 rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-500" role="alert">
              {chat.error}
            </p>
          )}

          {!interim && lastUser && (
            <div className="card mt-8 w-full space-y-3 p-4 text-left animate-fadeUp">
              <p className="text-sm text-mute">
                <span className="font-medium text-fg">You:</span> {lastUser.content}
              </p>
              {lastBot && <p className="whitespace-pre-wrap text-[15px] leading-relaxed">{lastBot.content || '…'}</p>}
            </div>
          )}

          <div className="mt-8 flex flex-wrap items-center justify-center gap-4 text-sm text-mute">
            {sttSupported && (
              <label className="inline-flex cursor-pointer items-center gap-2">
                <input type="checkbox" checked={handsFree} onChange={(e) => setHandsFree(e.target.checked)} className="h-4 w-4 accent-brand-purple" />
                Hands-free (keep listening after each answer)
              </label>
            )}
            {chat.messages.length > 0 && (
              <button
                onClick={() => {
                  stopSpeaking();
                  chat.reset();
                  setPhase('idle');
                }}
                className="inline-flex items-center gap-1.5 hover:text-fg"
              >
                <RotateCcw size={14} /> New voice chat
              </button>
            )}
          </div>

          {!profile.voice_enabled && <p className="mt-4 text-xs text-mute">Spoken replies are off. Turn them on in Settings → Voice.</p>}
          {!sttSupported && (
            <p className="mt-4 max-w-sm text-sm text-mute">Voice input isn’t supported in this browser, so please type below. For the full experience use Chrome or Edge.</p>
          )}
        </div>
      </div>

      {!sttSupported && (
        <Composer
          sending={chat.sending}
          lang={profile.language}
          allowFiles={false}
          placeholder="Type your question…"
          onSend={(t) => {
            setPhase('thinking');
            chat.send(t);
          }}
          onStop={chat.stop}
        />
      )}
    </div>
  );
}
