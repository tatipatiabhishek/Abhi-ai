import { useEffect, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Bug, Globe, Languages, Lightbulb, PenLine, X } from 'lucide-react';
import { Composer } from '../components/Composer';
import { MessageBubble } from '../components/MessageBubble';
import { Orb } from '../components/Orb';
import { useChat } from '../hooks/useChat';
import { useConversations } from '../hooks/useConversations';
import { useProfile } from '../hooks/useProfile';
import { useToast } from '../hooks/useToast';
import { api } from '../lib/api';
import { speak, stopSpeaking, ttsSupported } from '../lib/speech';
import type { Msg } from '../lib/types';
import { useAuth } from '../hooks/useAuth';

const SUGGESTIONS = [
  { icon: Lightbulb, text: 'Explain how the internet works in simple words' },
  { icon: Bug, text: 'Write a Python function to check if a number is prime, and explain it' },
  { icon: Languages, text: 'తెలుగులో నాకు ఒక చిన్న కథ చెప్పు' },
  { icon: PenLine, text: 'Help me write a polite email asking for a day off' },
];

export default function ChatPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { refresh } = useConversations();
  const { profile, models, defaultModel, update } = useProfile();
  const chat = useChat({ onChanged: refresh });
  const toast = useToast();
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const scroller = useRef<HTMLDivElement>(null);

  // Load or reset when the URL changes (skip when we just created this conversation ourselves).
  useEffect(() => {
    if (id) {
      if (id !== chat.conversationId) chat.load(id);
    } else {
      chat.reset();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  // After the first message creates a conversation, put its id in the URL.
  useEffect(() => {
    if (chat.conversationId && !id) navigate(`/chat/${chat.conversationId}`, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chat.conversationId]);

  // Keep the newest message in view.
  useEffect(() => {
    scroller.current?.scrollTo({ top: scroller.current.scrollHeight, behavior: 'smooth' });
  }, [chat.messages]);

  useEffect(() => () => stopSpeaking(), []);

  const onSpeak = (msg: Msg) => {
    if (speakingId === msg.id) {
      stopSpeaking();
      setSpeakingId(null);
      return;
    }
    setSpeakingId(msg.id);
    speak(msg.content, profile.language, profile.voice_rate).then(() => setSpeakingId((cur) => (cur === msg.id ? null : cur)));
  };

  const onRemember = async (msg: Msg) => {
    try {
      await api('/memories', { json: { content: msg.content.slice(0, 500) } });
      toast.show('Saved to memory 🧠');
    } catch (e) {
      toast.show((e as Error).message);
    }
  };

  const empty = chat.messages.length === 0 && !chat.loadingHistory;
  const name = profile.display_name || user?.email?.split('@')[0] || '';
  const activeModel = profile.model && models.includes(profile.model) ? profile.model : defaultModel;

  return (
    <div className="flex h-full flex-col">
      {/* Toolbar */}
      <div className="flex items-center justify-end gap-2 border-b border-line/60 px-4 py-2 text-xs">
        <button
          onClick={() => update({ web_search: !profile.web_search }).catch((e) => toast.show(e.message))}
          className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 transition ${
            profile.web_search ? 'border-brand-blue/50 bg-brand-blue/10 text-brand-blue' : 'border-line text-mute'
          }`}
          title="Let ABHI AI search the web for current information"
        >
          <Globe size={13} /> Web search {profile.web_search ? 'on' : 'off'}
        </button>
        {models.length > 1 && (
          <select
            value={activeModel}
            onChange={(e) => update({ model: e.target.value }).catch((er) => toast.show(er.message))}
            className="max-w-[170px] rounded-full border border-line bg-panel px-2.5 py-1 text-xs outline-none"
            aria-label="AI model"
          >
            {models.map((m) => (
              <option key={m} value={m}>
                {m}
              </option>
            ))}
          </select>
        )}
      </div>

      {/* Messages */}
      <div ref={scroller} className="min-h-0 flex-1 overflow-y-auto">
        <div className="mx-auto w-full max-w-3xl space-y-6 px-4 py-6">
          {chat.loadingHistory && <p className="py-10 text-center text-sm text-mute">Loading conversation…</p>}

          {empty && (
            <div className="flex flex-col items-center pt-6 text-center md:pt-14">
              <Orb size={120} />
              <h1 className="mt-6 font-display text-3xl font-semibold tracking-tight">
                Hello{name ? `, ` : ''}
                <span className="gradient-text">{name}</span>
              </h1>
              <p className="mt-2 max-w-md text-mute">Ask me anything, share an image or PDF, or tap the mic and talk. I speak English, తెలుగు and हिन्दी.</p>
              <div className="mt-8 grid w-full max-w-2xl gap-2.5 sm:grid-cols-2">
                {SUGGESTIONS.map(({ icon: Icon, text }) => (
                  <button
                    key={text}
                    onClick={() => chat.send(text)}
                    className="card flex items-start gap-3 p-3.5 text-left text-sm transition hover:border-brand-blue/50 hover:bg-panel"
                  >
                    <Icon size={18} className="mt-0.5 shrink-0 text-brand-blue" />
                    <span>{text}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {chat.messages.map((m) => (
            <MessageBubble
              key={m.id}
              msg={m}
              speaking={speakingId === m.id}
              onSpeak={ttsSupported ? onSpeak : undefined}
              onRemember={profile.memory_enabled ? onRemember : undefined}
            />
          ))}

          {chat.error && (
            <div className="flex items-start justify-between gap-3 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-500" role="alert">
              <span>{chat.error}</span>
              <button onClick={() => chat.setError(null)} aria-label="Dismiss error">
                <X size={16} />
              </button>
            </div>
          )}
        </div>
      </div>

      <Composer sending={chat.sending} lang={profile.language} onSend={(t, f) => chat.send(t, f)} onStop={chat.stop} />
      {toast.node}
    </div>
  );
}
