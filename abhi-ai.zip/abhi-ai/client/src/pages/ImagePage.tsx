import { useEffect, useRef, useState } from 'react';
import { Camera, ImagePlus, ScanText, Sparkles, X } from 'lucide-react';
import { MessageBubble } from '../components/MessageBubble';
import { useChat } from '../hooks/useChat';
import { useConversations } from '../hooks/useConversations';
import { useProfile } from '../hooks/useProfile';
import { filesToPending } from '../lib/files';
import { speak, stopSpeaking, ttsSupported } from '../lib/speech';
import type { Msg, PendingFile } from '../lib/types';

const QUICK = [
  'Describe this image in detail.',
  'Read and extract all text in this image.',
  'What is in this image and is anything unusual?',
  'Explain this like I am a beginner.',
];

export default function ImagePage() {
  const { profile } = useProfile();
  const { refresh } = useConversations();
  const chat = useChat({ onChanged: refresh });
  const [images, setImages] = useState<PendingFile[]>([]);
  const [question, setQuestion] = useState('');
  const [note, setNote] = useState<string | null>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const pickRef = useRef<HTMLInputElement>(null);
  const camRef = useRef<HTMLInputElement>(null);
  const answerRef = useRef<HTMLDivElement>(null);

  useEffect(() => () => stopSpeaking(), []);
  useEffect(() => {
    answerRef.current?.scrollTo({ top: answerRef.current.scrollHeight, behavior: 'smooth' });
  }, [chat.messages]);

  const addFiles = async (list: FileList | null) => {
    if (!list?.length) return;
    const picked = Array.from(list);
    if (picked.some((f) => !f.type.startsWith('image/'))) {
      setNote('Only image files can be used on this page. For PDFs or text files, attach them in Chat.');
      return;
    }
    try {
      const added = await filesToPending(picked, images);
      setImages((cur) => [...cur, ...added]);
      setNote(null);
    } catch (e) {
      setNote((e as Error).message);
    }
    if (pickRef.current) pickRef.current.value = '';
    if (camRef.current) camRef.current.value = '';
  };

  const ask = (text: string) => {
    if (!images.length) {
      setNote('Add an image first.');
      return;
    }
    if (!text.trim() || chat.sending) return;
    setNote(null);
    // Images are sent with every question so follow-ups can still "see" them.
    chat.send(text, images);
    setQuestion('');
  };

  const onSpeak = (msg: Msg) => {
    if (speakingId === msg.id) {
      stopSpeaking();
      setSpeakingId(null);
      return;
    }
    setSpeakingId(msg.id);
    speak(msg.content, profile.language, profile.voice_rate).then(() => setSpeakingId((c) => (c === msg.id ? null : c)));
  };

  return (
    <div className="h-full overflow-y-auto md:overflow-hidden">
      <div className="mx-auto grid min-h-full max-w-6xl gap-4 p-4 md:h-full md:grid-cols-2">
        {/* Left: upload + question */}
        <section className="flex flex-col gap-4 md:overflow-y-auto">
          <div>
            <h1 className="font-display text-2xl font-semibold">Image analysis</h1>
            <p className="text-sm text-mute">Upload a photo, screenshot or document image and ask anything about it.</p>
          </div>

          <input ref={pickRef} type="file" accept="image/png,image/jpeg,image/webp,image/gif" multiple hidden onChange={(e) => addFiles(e.target.files)} />
          <input ref={camRef} type="file" accept="image/*" capture="environment" hidden onChange={(e) => addFiles(e.target.files)} />

          {images.length === 0 ? (
            <button
              onClick={() => pickRef.current?.click()}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                addFiles(e.dataTransfer.files);
              }}
              className="card grid min-h-[220px] place-items-center border-dashed p-6 text-center transition hover:border-brand-blue/60"
            >
              <span>
                <ImagePlus className="mx-auto mb-3 text-brand-blue" size={36} />
                <span className="block font-medium">Tap to choose an image</span>
                <span className="mt-1 block text-sm text-mute">or drag and drop · PNG, JPG, WEBP, GIF</span>
              </span>
            </button>
          ) : (
            <div className="grid grid-cols-2 gap-2.5">
              {images.map((f, i) => (
                <div key={i} className="card relative overflow-hidden">
                  <img src={f.previewUrl} alt={f.name} className="h-40 w-full object-cover" />
                  <button
                    onClick={() => setImages((cur) => cur.filter((_, j) => j !== i))}
                    className="absolute right-1.5 top-1.5 grid h-7 w-7 place-items-center rounded-full bg-black/60 text-white"
                    aria-label={`Remove ${f.name}`}
                  >
                    <X size={14} />
                  </button>
                </div>
              ))}
            </div>
          )}

          <div className="flex flex-wrap gap-2">
            <button onClick={() => pickRef.current?.click()} className="btn-ghost">
              <ImagePlus size={16} /> {images.length ? 'Add more' : 'Choose image'}
            </button>
            <button onClick={() => camRef.current?.click()} className="btn-ghost">
              <Camera size={16} /> Take photo
            </button>
          </div>

          {note && <p className="rounded-lg bg-amber-500/10 px-3 py-2 text-sm text-amber-600 dark:text-amber-400">{note}</p>}

          <div className="flex flex-wrap gap-2">
            {QUICK.map((q) => (
              <button
                key={q}
                onClick={() => ask(q)}
                disabled={chat.sending}
                className="rounded-full border border-line bg-panel/60 px-3 py-1.5 text-xs text-mute transition hover:border-brand-blue/60 hover:text-fg disabled:opacity-50"
              >
                {q.startsWith('Read') ? <ScanText size={12} className="mr-1 inline" /> : null}
                {q}
              </button>
            ))}
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              ask(question);
            }}
            className="flex gap-2"
          >
            <input
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              maxLength={2000}
              placeholder="Ask a question about the image…"
              className="input"
              aria-label="Question about the image"
            />
            <button type="submit" disabled={!question.trim() || chat.sending} className="btn-primary shrink-0">
              <Sparkles size={16} /> Ask
            </button>
          </form>
        </section>

        {/* Right: answers */}
        <section ref={answerRef} className="card min-h-[240px] space-y-5 overflow-y-auto p-4">
          {chat.messages.length === 0 && (
            <div className="grid h-full min-h-[200px] place-items-center text-center text-sm text-mute">
              <p>Answers will appear here.</p>
            </div>
          )}
          {chat.messages.map((m) =>
            m.role === 'user' ? (
              <p key={m.id} className="rounded-xl bg-brand-blue/10 px-3 py-2 text-sm">
                {m.content}
              </p>
            ) : (
              <MessageBubble key={m.id} msg={m} speaking={speakingId === m.id} onSpeak={ttsSupported ? onSpeak : undefined} />
            )
          )}
          {chat.error && (
            <p className="rounded-xl border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-500" role="alert">
              {chat.error}
            </p>
          )}
        </section>
      </div>
    </div>
  );
}
