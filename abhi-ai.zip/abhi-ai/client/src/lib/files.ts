import type { PendingFile } from './types';

export const ACCEPT = 'image/png,image/jpeg,image/webp,image/gif,application/pdf,text/plain,.txt';
export const MAX_FILES = 4;
const MAX_IMAGE_INPUT_BYTES = 20 * 1024 * 1024; // images are shrunk before sending
const MAX_DOC_BYTES = 3 * 1024 * 1024; // PDF / TXT are sent as-is
// Vercel rejects request bodies over 4.5 MB, so keep the total payload below that.
const MAX_TOTAL_BASE64 = 4 * 1024 * 1024;

const ALLOWED = ['image/png', 'image/jpeg', 'image/webp', 'image/gif', 'application/pdf', 'text/plain'];

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Could not read the file.'));
    reader.onload = () => resolve(String(reader.result).split(',')[1] ?? '');
    reader.readAsDataURL(blob);
  });
}

/** Shrinks large photos (max 1600px, JPEG) so uploads are fast and stay within server limits. */
async function shrinkImage(file: File): Promise<{ blob: Blob; mimeType: string; name: string }> {
  const keep = { blob: file as Blob, mimeType: file.type, name: file.name };
  if (file.type === 'image/gif' || file.size < 400 * 1024) return keep;
  try {
    const bitmap = await createImageBitmap(file);
    const scale = Math.min(1, 1600 / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(bitmap.width * scale);
    canvas.height = Math.round(bitmap.height * scale);
    const ctx = canvas.getContext('2d');
    if (!ctx) return keep;
    ctx.fillStyle = '#fff'; // flatten transparency for JPEG
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    bitmap.close?.();
    const blob = await new Promise<Blob | null>((res) => canvas.toBlob(res, 'image/jpeg', 0.85));
    if (!blob || blob.size >= file.size) return keep;
    return { blob, mimeType: 'image/jpeg', name: file.name.replace(/\.\w+$/, '') + '.jpg' };
  } catch {
    return keep; // fall back to the original if the browser cannot decode it
  }
}

/** Validates and converts user-selected files. Throws Error with a friendly message. */
export async function filesToPending(files: File[], existing: PendingFile[] = []): Promise<PendingFile[]> {
  if (existing.length + files.length > MAX_FILES) throw new Error(`You can attach up to ${MAX_FILES} files per message.`);
  let total = existing.reduce((sum, f) => sum + f.data.length, 0);
  const out: PendingFile[] = [];

  for (const f of files) {
    const type = f.type || (f.name.toLowerCase().endsWith('.txt') ? 'text/plain' : '');
    if (!ALLOWED.includes(type)) throw new Error(`${f.name}: only images, PDF and TXT files are supported.`);
    const isImage = type.startsWith('image/');
    if (isImage && f.size > MAX_IMAGE_INPUT_BYTES) throw new Error(`${f.name} is larger than 20 MB.`);
    if (!isImage && f.size > MAX_DOC_BYTES) throw new Error(`${f.name} is larger than 3 MB. Try a smaller file.`);

    const prepared = isImage ? await shrinkImage(f) : { blob: f as Blob, mimeType: type, name: f.name };
    const data = await blobToBase64(prepared.blob);
    total += data.length;
    if (total > MAX_TOTAL_BASE64) throw new Error('Attachments are too large together (about 3 MB total). Remove one or use smaller files.');

    out.push({
      name: prepared.name,
      mimeType: prepared.mimeType,
      data,
      previewUrl: isImage ? URL.createObjectURL(prepared.blob) : undefined,
    });
  }
  return out;
}
