import { supabase } from './supabase';
import type { Lang, PendingFile, Source } from './types';

async function authToken(): Promise<string | undefined> {
  const { data } = await supabase.auth.getSession();
  return data.session?.access_token;
}

/** JSON helper for the ABHI AI backend. Throws Error with a human-readable message. */
export async function api<T = any>(path: string, opts: { method?: string; json?: unknown } = {}): Promise<T> {
  const headers: Record<string, string> = {};
  const token = await authToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  if (opts.json !== undefined) headers['Content-Type'] = 'application/json';

  let res: Response;
  try {
    res = await fetch(`/api${path}`, {
      method: opts.method || (opts.json !== undefined ? 'POST' : 'GET'),
      headers,
      body: opts.json !== undefined ? JSON.stringify(opts.json) : undefined,
    });
  } catch {
    throw new Error('Cannot reach the server. Check your internet connection.');
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as any).error || `Request failed (${res.status})`);
  return data as T;
}

export interface ChatPayload {
  conversationId?: string;
  message: string;
  language: Lang;
  model?: string | null;
  webSearch?: boolean;
  voiceMode?: boolean;
  attachments: Pick<PendingFile, 'name' | 'mimeType' | 'data'>[];
}

export interface StreamHandlers {
  onStart?: (conversationId: string) => void;
  onDelta: (text: string) => void;
  onDone?: (info: { messageId?: string; sources: Source[] }) => void;
}

/** Sends a chat message and reads the streamed (SSE) reply. */
export async function streamChat(payload: ChatPayload, handlers: StreamHandlers, signal?: AbortSignal): Promise<void> {
  const token = await authToken();
  let res: Response;
  try {
    res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify({ ...payload, model: payload.model || undefined }),
      signal,
    });
  } catch (e) {
    if ((e as Error).name === 'AbortError') throw e;
    throw new Error('Cannot reach the server. Check your internet connection.');
  }

  if (!res.ok || !res.body) {
    const data = await res.json().catch(() => ({}));
    throw new Error((data as any).error || `Request failed (${res.status})`);
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  const handle = (raw: string) => {
    const line = raw.split('\n').find((l) => l.startsWith('data:'));
    if (!line) return;
    let evt: any;
    try {
      evt = JSON.parse(line.slice(5).trim());
    } catch {
      return;
    }
    if (evt.type === 'start') handlers.onStart?.(evt.conversationId);
    else if (evt.type === 'delta') handlers.onDelta(evt.text);
    else if (evt.type === 'done') handlers.onDone?.({ messageId: evt.messageId, sources: evt.sources ?? [] });
    else if (evt.type === 'error') throw new Error(evt.message || 'The AI could not answer.');
  };

  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    let idx: number;
    while ((idx = buffer.indexOf('\n\n')) !== -1) {
      const raw = buffer.slice(0, idx);
      buffer = buffer.slice(idx + 2);
      handle(raw);
    }
  }
}
