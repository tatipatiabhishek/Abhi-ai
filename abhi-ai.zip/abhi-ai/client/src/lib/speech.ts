import { LANGUAGES, type Lang } from './types';

export const speechLocale = (lang: Lang) => LANGUAGES.find((l) => l.code === lang)?.speech ?? 'en-IN';

/** Removes Markdown so text-to-speech does not read symbols aloud. */
export function stripMarkdown(md: string): string {
  return md
    .replace(/```[\s\S]*?```/g, ' (code omitted) ')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/!\[[^\]]*\]\([^)]*\)/g, '')
    .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1')
    .replace(/^#{1,6}\s*/gm, '')
    .replace(/(\*\*|__|\*|_|~~)/g, '')
    .replace(/^\s*[-*+]\s+/gm, '')
    .replace(/^\s*\d+\.\s+/gm, '')
    .replace(/^>\s?/gm, '')
    .replace(/\|/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

// ---------- Text to speech ----------
export const ttsSupported = typeof window !== 'undefined' && 'speechSynthesis' in window;

function pickVoice(locale: string): SpeechSynthesisVoice | undefined {
  const voices = window.speechSynthesis.getVoices();
  const prefix = locale.split('-')[0];
  return voices.find((v) => v.lang === locale) || voices.find((v) => v.lang.toLowerCase().startsWith(prefix));
}

// Each speak()/stopSpeaking() call bumps this so a cancelled speech never continues with its next chunk.
let speechSession = 0;

export function stopSpeaking() {
  speechSession++;
  if (ttsSupported) window.speechSynthesis.cancel();
}

/** Speaks text aloud. Resolves when finished or stopped (or immediately if unsupported). */
export function speak(text: string, lang: Lang, rate = 1): Promise<void> {
  return new Promise((resolve) => {
    if (!ttsSupported) return resolve();
    const clean = stripMarkdown(text);
    if (!clean) return resolve();
    stopSpeaking();
    const session = speechSession;

    // Long text is split so browsers (notably Chrome) do not cut speech off mid-way.
    const chunks = clean.match(/[^.!?।\n]+[.!?।]*\s*/g) ?? [clean];
    const locale = speechLocale(lang);
    let i = 0;
    const next = () => {
      if (session !== speechSession || i >= chunks.length) return resolve();
      const u = new SpeechSynthesisUtterance(chunks[i++].trim());
      u.lang = locale;
      u.rate = rate;
      const voice = pickVoice(locale);
      if (voice) u.voice = voice;
      u.onend = next;
      u.onerror = () => resolve();
      window.speechSynthesis.speak(u);
    };
    next();
  });
}

// ---------- Speech to text ----------
const Recognition: any =
  typeof window !== 'undefined' ? (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition : undefined;

export const sttSupported = Boolean(Recognition);

export interface Listener {
  stop: () => void;
}

/**
 * Starts the browser's speech recognition.
 * onResult gets interim text while speaking and the final text once (final = true).
 */
export function listen(
  lang: Lang,
  handlers: { onResult: (text: string, final: boolean) => void; onEnd: () => void; onError: (message: string) => void }
): Listener | null {
  if (!Recognition) {
    handlers.onError('Voice input is not supported in this browser. Try Chrome or Edge.');
    return null;
  }
  const rec = new Recognition();
  rec.lang = speechLocale(lang);
  rec.interimResults = true;
  rec.continuous = false;
  rec.maxAlternatives = 1;

  rec.onresult = (e: any) => {
    let text = '';
    let final = false;
    for (let i = e.resultIndex; i < e.results.length; i++) {
      text += e.results[i][0].transcript;
      if (e.results[i].isFinal) final = true;
    }
    handlers.onResult(text.trim(), final);
  };
  rec.onerror = (e: any) => {
    const map: Record<string, string> = {
      'not-allowed': 'Microphone permission was denied. Allow it in your browser settings.',
      'service-not-allowed': 'Microphone permission was denied. Allow it in your browser settings.',
      'no-speech': 'I did not hear anything. Tap the mic and try again.',
      'audio-capture': 'No microphone was found.',
      network: 'Speech recognition needs an internet connection.',
      'language-not-supported': 'That language is not supported for voice input on this device.',
    };
    if (e.error !== 'aborted') handlers.onError(map[e.error] || `Voice input error: ${e.error}`);
  };
  rec.onend = handlers.onEnd;

  try {
    rec.start();
  } catch {
    handlers.onError('Could not start the microphone.');
    return null;
  }
  return { stop: () => rec.stop() };
}
