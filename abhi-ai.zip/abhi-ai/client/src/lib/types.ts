export type Lang = 'en' | 'te' | 'hi';

export interface Profile {
  id: string;
  display_name: string | null;
  language: Lang;
  voice_enabled: boolean;
  voice_rate: number;
  model: string | null;
  web_search: boolean;
  memory_enabled: boolean;
}

export interface Source {
  title: string;
  uri: string;
}

export interface AttachmentMeta {
  name: string;
  mimeType: string;
}

export interface Msg {
  id: string;
  role: 'user' | 'model';
  content: string;
  attachments?: AttachmentMeta[];
  sources?: Source[];
  pending?: boolean;
  error?: boolean;
}

/** A file ready to send to the API (base64 payload) plus a local preview URL for images. */
export interface PendingFile extends AttachmentMeta {
  data: string;
  previewUrl?: string;
}

export interface ConversationSummary {
  id: string;
  title: string;
  created_at: string;
  updated_at: string;
}

export interface Memory {
  id: string;
  content: string;
  created_at: string;
}

export const LANGUAGES: { code: Lang; label: string; native: string; speech: string }[] = [
  { code: 'en', label: 'English', native: 'English', speech: 'en-IN' },
  { code: 'te', label: 'Telugu', native: 'తెలుగు', speech: 'te-IN' },
  { code: 'hi', label: 'Hindi', native: 'हिन्दी', speech: 'hi-IN' },
];
