import path from 'path';
import dotenv from 'dotenv';

// Load .env from the repo root (no-op on Vercel, where env vars are injected).
dotenv.config({ path: path.resolve(__dirname, '../../.env') });

const models = (process.env.GEMINI_MODELS || 'gemini-2.5-flash,gemini-2.5-pro,gemini-2.5-flash-lite')
  .split(',')
  .map((m) => m.trim())
  .filter(Boolean);

export const config = {
  port: Number(process.env.PORT || 8787),
  geminiApiKey: process.env.GEMINI_API_KEY || '',
  models,
  defaultModel: models[0],
  supabaseUrl: process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL || '',
  supabaseAnonKey: process.env.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY || '',
  corsOrigins: (process.env.CORS_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean),
  maxHistoryMessages: 30,
};

export function assertConfig(): string[] {
  const missing: string[] = [];
  if (!config.geminiApiKey) missing.push('GEMINI_API_KEY');
  if (!config.supabaseUrl) missing.push('SUPABASE_URL');
  if (!config.supabaseAnonKey) missing.push('SUPABASE_ANON_KEY');
  return missing;
}
