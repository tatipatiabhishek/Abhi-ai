import { config } from '../config';

export type Part =
  | { text: string }
  | { inlineData: { mimeType: string; data: string } };

export interface GeminiContent {
  role: 'user' | 'model';
  parts: Part[];
}

export interface StreamOptions {
  model: string;
  systemInstruction: string;
  contents: GeminiContent[];
  webSearch: boolean;
  onText: (text: string) => void;
  signal?: AbortSignal;
}

export interface Source {
  title: string;
  uri: string;
}

export class GeminiError extends Error {
  status: number;
  constructor(message: string, status = 502) {
    super(message);
    this.status = status;
  }
}

function friendlyError(status: number, body: string): GeminiError {
  let detail = '';
  try {
    detail = JSON.parse(body)?.error?.message || '';
  } catch {
    /* ignore */
  }
  if (status === 400 && /API key/i.test(detail)) return new GeminiError('The Gemini API key is invalid. Check GEMINI_API_KEY on the server.', 500);
  if (status === 401 || status === 403) return new GeminiError('Gemini rejected the request. Check that your API key is valid and has access to this model.', 502);
  if (status === 404) return new GeminiError('That AI model was not found. Pick a different model in Settings or update GEMINI_MODELS.', 400);
  if (status === 429) return new GeminiError('The AI is busy or your quota is used up. Please try again in a moment.', 429);
  return new GeminiError(detail || `The AI service returned an error (${status}).`, 502);
}

/**
 * Streams a response from the Gemini REST API (server-sent events) and
 * returns the collected web-search sources, if any.
 */
export async function streamGemini(opts: StreamOptions): Promise<Source[]> {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(opts.model)}:streamGenerateContent?alt=sse`;

  const body: Record<string, unknown> = {
    systemInstruction: { parts: [{ text: opts.systemInstruction }] },
    contents: opts.contents,
    generationConfig: { temperature: 0.8 },
  };
  if (opts.webSearch) body.tools = [{ google_search: {} }];

  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': config.geminiApiKey },
    body: JSON.stringify(body),
    signal: opts.signal,
  });

  if (!res.ok || !res.body) throw friendlyError(res.status, await res.text().catch(() => ''));

  const sources = new Map<string, Source>();
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  const handleEvent = (raw: string) => {
    const dataLines = raw
      .split('\n')
      .filter((l) => l.startsWith('data:'))
      .map((l) => l.slice(5).trim());
    if (!dataLines.length) return;
    let json: any;
    try {
      json = JSON.parse(dataLines.join(''));
    } catch {
      return;
    }
    if (json.promptFeedback?.blockReason) {
      throw new GeminiError('That request was blocked by the AI safety filters. Try rephrasing it.', 400);
    }
    const candidate = json.candidates?.[0];
    for (const part of candidate?.content?.parts ?? []) {
      if (typeof part.text === 'string' && !part.thought) opts.onText(part.text);
    }
    for (const chunk of candidate?.groundingMetadata?.groundingChunks ?? []) {
      if (chunk.web?.uri) sources.set(chunk.web.uri, { title: chunk.web.title || chunk.web.uri, uri: chunk.web.uri });
    }
  };

  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    let idx: number;
    while ((idx = buffer.search(/\r?\n\r?\n/)) !== -1) {
      const raw = buffer.slice(0, idx);
      buffer = buffer.slice(idx).replace(/^\r?\n\r?\n/, '');
      handleEvent(raw);
    }
  }
  if (buffer.trim()) handleEvent(buffer);

  return [...sources.values()].slice(0, 8);
}
