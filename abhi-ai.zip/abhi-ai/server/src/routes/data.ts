import { Router } from 'express';
import { z } from 'zod';
import { config } from '../config';
import { requireAuth } from '../middleware/auth';

const router = Router();
router.use(requireAuth);

const idSchema = z.string().uuid();

// ---- Models ---------------------------------------------------------------
router.get('/models', (_req, res) => {
  res.json({ models: config.models, default: config.defaultModel });
});

// ---- Conversations --------------------------------------------------------
router.get('/conversations', async (req, res) => {
  const { data, error } = await req.db!
    .from('conversations')
    .select('id, title, created_at, updated_at')
    .order('updated_at', { ascending: false })
    .limit(300);
  if (error) return res.status(500).json({ error: 'Could not load your conversations.' });
  res.json({ conversations: data });
});

router.get('/conversations/:id', async (req, res) => {
  if (!idSchema.safeParse(req.params.id).success) return res.status(400).json({ error: 'Invalid conversation id.' });
  const db = req.db!;
  const { data: conversation } = await db.from('conversations').select('id, title, updated_at').eq('id', req.params.id).maybeSingle();
  if (!conversation) return res.status(404).json({ error: 'Conversation not found.' });
  const { data: messages, error } = await db
    .from('messages')
    .select('id, role, content, attachments, sources, created_at')
    .eq('conversation_id', req.params.id)
    .order('created_at', { ascending: true });
  if (error) return res.status(500).json({ error: 'Could not load messages.' });
  res.json({ conversation, messages });
});

router.patch('/conversations/:id', async (req, res) => {
  const parsed = z.object({ title: z.string().trim().min(1).max(100) }).safeParse(req.body);
  if (!idSchema.safeParse(req.params.id).success || !parsed.success) return res.status(400).json({ error: 'Invalid request.' });
  const { error } = await req.db!.from('conversations').update({ title: parsed.data.title }).eq('id', req.params.id);
  if (error) return res.status(500).json({ error: 'Could not rename the conversation.' });
  res.json({ ok: true });
});

router.delete('/conversations/:id', async (req, res) => {
  if (!idSchema.safeParse(req.params.id).success) return res.status(400).json({ error: 'Invalid conversation id.' });
  const { error } = await req.db!.from('conversations').delete().eq('id', req.params.id);
  if (error) return res.status(500).json({ error: 'Could not delete the conversation.' });
  res.json({ ok: true });
});

router.delete('/conversations', async (req, res) => {
  const { error } = await req.db!.from('conversations').delete().eq('user_id', req.userId!);
  if (error) return res.status(500).json({ error: 'Could not delete your conversations.' });
  res.json({ ok: true });
});

// ---- Memories (saved only when the user approves) -------------------------
router.get('/memories', async (req, res) => {
  const { data, error } = await req.db!.from('memories').select('id, content, created_at').order('created_at', { ascending: false });
  if (error) return res.status(500).json({ error: 'Could not load memories.' });
  res.json({ memories: data });
});

router.post('/memories', async (req, res) => {
  const parsed = z.object({ content: z.string().trim().min(1).max(500) }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'A memory must be 1-500 characters.' });
  const { count } = await req.db!.from('memories').select('id', { count: 'exact', head: true });
  if ((count ?? 0) >= 100) return res.status(400).json({ error: 'You have reached the 100 memory limit. Delete some first.' });
  const { data, error } = await req.db!
    .from('memories')
    .insert({ user_id: req.userId!, content: parsed.data.content })
    .select('id, content, created_at')
    .single();
  if (error) return res.status(500).json({ error: 'Could not save the memory.' });
  res.status(201).json({ memory: data });
});

router.delete('/memories/:id', async (req, res) => {
  if (!idSchema.safeParse(req.params.id).success) return res.status(400).json({ error: 'Invalid memory id.' });
  const { error } = await req.db!.from('memories').delete().eq('id', req.params.id);
  if (error) return res.status(500).json({ error: 'Could not delete the memory.' });
  res.json({ ok: true });
});

router.delete('/memories', async (req, res) => {
  const { error } = await req.db!.from('memories').delete().eq('user_id', req.userId!);
  if (error) return res.status(500).json({ error: 'Could not clear memories.' });
  res.json({ ok: true });
});

// ---- Profile / settings ---------------------------------------------------
const profileSchema = z
  .object({
    display_name: z.string().trim().max(60),
    language: z.enum(['en', 'te', 'hi']),
    voice_enabled: z.boolean(),
    voice_rate: z.number().min(0.5).max(2),
    model: z.string().max(100).nullable(),
    web_search: z.boolean(),
    memory_enabled: z.boolean(),
  })
  .partial();

router.get('/profile', async (req, res) => {
  const { data, error } = await req.db!.from('profiles').select('*').eq('id', req.userId!).maybeSingle();
  if (error) return res.status(500).json({ error: 'Could not load your profile.' });
  if (data) return res.json({ profile: data });
  // Profile row missing (e.g. user created before the trigger existed): create it.
  const { data: created } = await req.db!.from('profiles').insert({ id: req.userId! }).select('*').single();
  res.json({ profile: created });
});

router.patch('/profile', async (req, res) => {
  const parsed = profileSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid settings.' });
  const { data, error } = await req.db!.from('profiles').update(parsed.data).eq('id', req.userId!).select('*').single();
  if (error) return res.status(500).json({ error: 'Could not save settings.' });
  res.json({ profile: data });
});

export default router;
