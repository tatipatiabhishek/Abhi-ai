import { Router, Request, Response } from 'express';
import { z } from 'zod';
import { config } from '../config';
import { requireAuth } from '../middleware/auth';
import { GeminiContent, GeminiError, Part, streamGemini } from '../lib/gemini';

const router = Router();

const ALLOWED_MIME = ['image/png', 'image/jpeg', 'image/webp', 'image/gif', 'application/pdf', 'text/plain'];
const MAX_ATTACHMENT_BASE64 = 5 * 1024 * 1024; // ~3.7 MB of raw file data per file

const bodySchema = z.object({
  conversationId: z.string().uuid().optional(),
  message: z.string().trim().min(1, 'Please type a message.').max(8000, 'Message is too long (8000 characters max).'),
  language: z.enum(['en', 'te', 'hi']).default('en'),
  model: z.string().max(100).optional(),
  webSearch: z.boolean().optional(),
  voiceMode: z.boolean().optional(),
  attachments: z
    .array(
      z.object({
        name: z.string().max(200),
        mimeType: z.enum(ALLOWED_MIME as [string, ...string[]]),
        data: z.string().max(MAX_ATTACHMENT_BASE64),
      })
    )
    .max(4)
    .default([]),
});

const LANGUAGE_NAMES = { en: 'English', te: 'Telugu (తెలుగు)', hi: 'Hindi (हिन्दी)' } as const;

function buildSystemPrompt(opts: {
  language: 'en' | 'te' | 'hi';
  memories: string[];
  userName?: string | null;
  voiceMode?: boolean;
}) {
  const lines = [
    'You are ABHI AI, a friendly, capable and honest personal AI assistant.',
    'You can chat, explain, write and debug code, analyse images and documents, and answer questions using up-to-date web search when it is enabled.',
    `Today's date is ${new Date().toISOString().slice(0, 10)}.`,
    `Default reply language: ${LANGUAGE_NAMES[opts.language]}. If the user writes in a different language (English, Telugu or Hindi), reply in the language they used.`,
    'Be clear and concise. Use Markdown (lists, bold, fenced code blocks with a language tag) when it helps readability.',
    'If you are unsure of something, say so instead of guessing.',
  ];
  if (opts.voiceMode) {
    lines.push(
      'The user is talking to you by voice and your reply will be read aloud. Reply in short, natural spoken sentences. Do NOT use Markdown, bullet lists, tables, emojis or code blocks.'
    );
  }
  if (opts.userName) lines.push(`The user's name is ${opts.userName}.`);
  if (opts.memories.length) {
    lines.push('Things the user has asked you to remember (use them naturally when relevant):');
    opts.memories.forEach((m) => lines.push(`- ${m}`));
  }
  return lines.join('\n');
}

function toContents(history: { role: 'user' | 'model'; content: string; attachments: any[] }[]): GeminiContent[] {
  const contents: GeminiContent[] = [];
  for (const m of history) {
    const attachNote = Array.isArray(m.attachments) && m.attachments.length
      ? `\n[User attached: ${m.attachments.map((a: any) => a.name).join(', ')}]`
      : '';
    const text = m.content + attachNote;
    const last = contents[contents.length - 1];
    if (last && last.role === m.role) (last.parts[0] as { text: string }).text += `\n\n${text}`;
    else contents.push({ role: m.role, parts: [{ text }] });
  }
  while (contents.length && contents[0].role !== 'user') contents.shift();
  return contents;
}

router.post('/', requireAuth, async (req: Request, res: Response) => {
  const parsed = bodySchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid request.' });
  }
  const body = parsed.data;
  const db = req.db!;
  const userId = req.userId!;

  const model = body.model && config.models.includes(body.model) ? body.model : config.defaultModel;

  // Load profile + approved memories
  const { data: profile } = await db.from('profiles').select('display_name, memory_enabled, web_search').eq('id', userId).maybeSingle();
  let memories: string[] = [];
  if (profile?.memory_enabled !== false) {
    const { data } = await db.from('memories').select('content').order('created_at', { ascending: false }).limit(50);
    memories = (data ?? []).map((m) => m.content);
  }
  const webSearch = body.webSearch ?? profile?.web_search ?? true;

  // Find or create the conversation
  let conversationId = body.conversationId;
  if (conversationId) {
    const { data: conv } = await db.from('conversations').select('id').eq('id', conversationId).maybeSingle();
    if (!conv) return res.status(404).json({ error: 'Conversation not found.' });
  } else {
    const title = body.message.replace(/\s+/g, ' ').slice(0, 60);
    const { data: conv, error } = await db.from('conversations').insert({ user_id: userId, title }).select('id').single();
    if (error || !conv) return res.status(500).json({ error: 'Could not start a new conversation.' });
    conversationId = conv.id as string;
  }

  // Conversation context
  const { data: historyRows } = await db
    .from('messages')
    .select('role, content, attachments')
    .eq('conversation_id', conversationId)
    .order('created_at', { ascending: false })
    .limit(config.maxHistoryMessages);
  const history = (historyRows ?? []).reverse() as { role: 'user' | 'model'; content: string; attachments: any[] }[];

  // Build the current user turn
  const parts: Part[] = [];
  for (const a of body.attachments) {
    if (a.mimeType === 'text/plain') {
      const text = Buffer.from(a.data, 'base64').toString('utf8').slice(0, 100_000);
      parts.push({ text: `File "${a.name}":\n\n${text}` });
    } else {
      parts.push({ inlineData: { mimeType: a.mimeType, data: a.data } });
    }
  }
  parts.push({ text: body.message });
  const contents = toContents(history);
  const last = contents[contents.length - 1];
  if (last && last.role === 'user') {
    // Gemini accepts consecutive same-role turns poorly after a failed reply; merge them into this turn.
    contents.pop();
    parts.unshift({ text: (last.parts[0] as { text: string }).text });
  }
  contents.push({ role: 'user', parts });

  // Save the user's message (attachment metadata only; file bytes are never stored)
  const { error: insertErr } = await db.from('messages').insert({
    conversation_id: conversationId,
    user_id: userId,
    role: 'user',
    content: body.message,
    attachments: body.attachments.map((a) => ({ name: a.name, mimeType: a.mimeType })),
  });
  if (insertErr) return res.status(500).json({ error: 'Could not save your message.' });

  // Start streaming (Server-Sent Events)
  res.status(200);
  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders?.();
  const send = (event: Record<string, unknown>) => res.write(`data: ${JSON.stringify(event)}\n\n`);
  send({ type: 'start', conversationId });

  const abort = new AbortController();
  res.on('close', () => abort.abort());

  let full = '';
  try {
    const sources = await streamGemini({
      model,
      systemInstruction: buildSystemPrompt({ language: body.language, memories, userName: profile?.display_name, voiceMode: body.voiceMode }),
      contents,
      webSearch,
      signal: abort.signal,
      onText: (t) => {
        full += t;
        send({ type: 'delta', text: t });
      },
    });

    if (!full.trim()) throw new GeminiError('The AI returned an empty answer. Please try again.');

    const { data: saved } = await db
      .from('messages')
      .insert({ conversation_id: conversationId, user_id: userId, role: 'model', content: full, sources })
      .select('id')
      .single();
    await db.from('conversations').update({ updated_at: new Date().toISOString() }).eq('id', conversationId);
    send({ type: 'done', messageId: saved?.id, sources });
  } catch (err) {
    if (abort.signal.aborted) {
      // Client stopped or disconnected: keep whatever was generated so far.
      if (full.trim()) {
        await db.from('messages').insert({ conversation_id: conversationId, user_id: userId, role: 'model', content: full });
      }
    } else {
      const message = err instanceof GeminiError ? err.message : 'Something went wrong while contacting the AI.';
      if (!(err instanceof GeminiError)) console.error('chat error:', err);
      send({ type: 'error', message });
    }
  } finally {
    res.end();
  }
});

export default router;
