import { NextFunction, Request, Response } from 'express';
import { SupabaseClient } from '@supabase/supabase-js';
import { supabaseForUser } from '../lib/supabase';

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      userId?: string;
      db?: SupabaseClient;
    }
  }
}

/** Verifies the Supabase access token from the Authorization header. */
export async function requireAuth(req: Request, res: Response, next: NextFunction) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  if (!token) return res.status(401).json({ error: 'Please sign in to continue.' });

  try {
    const db = supabaseForUser(token);
    const { data, error } = await db.auth.getUser(token);
    if (error || !data.user) return res.status(401).json({ error: 'Your session has expired. Please sign in again.' });
    req.userId = data.user.id;
    req.db = db;
    next();
  } catch {
    res.status(401).json({ error: 'Could not verify your session.' });
  }
}
