import path from 'path';
import fs from 'fs';
import express from 'express';
import app from './app';
import { assertConfig, config } from './config';

const missing = assertConfig();
if (missing.length) {
  console.warn(`\n⚠️  Missing environment variables: ${missing.join(', ')}\n   Copy .env.example to .env and fill them in.\n`);
}

// `npm start`: also serve the built frontend (run `npm run build` first).
const dist = path.resolve(__dirname, '../../dist');
if (fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.get('*', (_req, res) => res.sendFile(path.join(dist, 'index.html')));
}

app.listen(config.port, () => {
  console.log(`ABHI AI API listening on http://localhost:${config.port}`);
});
