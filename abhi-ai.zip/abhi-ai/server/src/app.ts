import 'express-async-errors'; // lets Express 4 forward errors thrown in async route handlers
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { assertConfig, config } from './config';
import chatRouter from './routes/chat';
import dataRouter from './routes/data';

const app = express();
app.set('trust proxy', 1);

app.use(helmet({ contentSecurityPolicy: false, crossOriginResourcePolicy: { policy: 'cross-origin' } }));

if (config.corsOrigins.length) {
  app.use(cors({ origin: config.corsOrigins, credentials: false }));
}

// Attachments arrive as base64, so allow a larger JSON body for the chat route only.
// (Vercel itself caps request bodies at 4.5 MB; the client keeps uploads under that.)
app.use('/api/chat', express.json({ limit: '6mb' }));
app.use(express.json({ limit: '100kb' }));

app.use('/api', rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many requests. Please slow down.' } }));
app.use('/api/chat', rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: true, legacyHeaders: false, message: { error: 'You are sending messages too quickly. Please wait a moment.' } }));

app.get('/api/health', (_req, res) => {
  const missing = assertConfig();
  res.json({ ok: missing.length === 0, missing });
});

app.use('/api/chat', chatRouter);
app.use('/api', dataRouter);

app.use('/api', (_req, res) => res.status(404).json({ error: 'Not found.' }));

// Central error handler (e.g. oversized or malformed JSON)
// eslint-disable-next-line @typescript-eslint/no-unused-vars
app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  if (err?.type === 'entity.too.large') return res.status(413).json({ error: 'That upload is too large. Try smaller files (about 3 MB total).' });
  if (err?.type === 'entity.parse.failed') return res.status(400).json({ error: 'Malformed request.' });
  console.error(err);
  res.status(500).json({ error: 'Unexpected server error.' });
});

export default app;
