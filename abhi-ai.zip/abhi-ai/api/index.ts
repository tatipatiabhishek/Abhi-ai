// Vercel serverless entry: all /api/* requests are handled by the Express app.
import app from '../server/src/app';

export default app;
