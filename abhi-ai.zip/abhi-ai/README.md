# ABHI AI – Personal AI Assistant

A full-stack AI assistant you can chat with, talk to, show images to, and ask to search the web. English, తెలుగు and हिन्दी.

**Stack:** React + TypeScript + Tailwind CSS · Node.js + Express · Supabase (Auth + Postgres) · Google Gemini API · Vercel · installable on Android as a PWA.

> **Status:** this code was generated without being able to run `npm install` or a build, so it has not been executed end to end. It was syntax-checked, but expect to fix a small issue or two on first run. Work through *Quick start* below and use *Troubleshooting* if something fails.

## Features

| Feature | How it works |
| --- | --- |
| AI chat | Streaming replies from Gemini, with conversation context and Markdown + copyable code blocks |
| Voice assistant | Browser speech recognition in, browser text-to-speech out (Telugu / Hindi / English), optional hands-free loop |
| Image understanding | Upload or photograph an image and ask questions (images are shrunk on your device first) |
| File upload | Images, PDF and TXT in chat |
| Web search | Gemini's built-in Google Search grounding, with source links under the answer |
| Smart memory | Saved **only** when you add it in Settings or tap *Remember this* on a message; deletable anytime |
| Chat history | Search, rename, delete, delete all |
| Multilingual | English, Telugu, Hindi (replies and voice) |
| Themes | Dark (default) and light |
| Settings / profile | Name, language, voice speed, model picker, web search, memory, privacy |
| Android | Installable PWA (*Add to Home screen*) |

## Project structure

```
abhi-ai/
├── api/index.ts            Vercel serverless entry (wraps the Express app)
├── server/src/
│   ├── app.ts              Express app: security headers, rate limits, routes
│   ├── index.ts            Local server (npm run dev / npm start)
│   ├── config.ts           Reads environment variables
│   ├── middleware/auth.ts  Verifies the Supabase login token
│   ├── lib/gemini.ts       Streaming Gemini client
│   ├── lib/supabase.ts     Per-user Supabase client (Row Level Security)
│   └── routes/             chat.ts (streaming) and data.ts (history, memory, profile)
├── client/
│   ├── public/             PWA manifest, service worker, icons
│   └── src/
│       ├── pages/          Landing, Auth, Chat, Voice, Image, History, Settings, Profile
│       ├── components/     AppShell, Composer, MessageBubble, Orb, Logo
│       ├── hooks/          Auth, profile, conversations, chat streaming, theme
│       └── lib/            API client, speech, file handling
├── supabase/schema.sql     Database tables + security policies
├── vercel.json
└── .env.example
```

## Quick start (local)

**Requirements:** Node.js 18 or newer, a free [Supabase](https://supabase.com) account, and a free [Gemini API key](https://aistudio.google.com/apikey).

### 1. Install

```bash
cd abhi-ai
npm install
```

### 2. Create the Supabase project

1. In Supabase, create a new project.
2. Open **SQL Editor → New query**, paste the contents of `supabase/schema.sql`, and click **Run**.
3. Open **Project Settings → API** and copy the **Project URL** and the **anon public** key.
4. (Easiest for testing) In **Authentication → Providers → Email**, you can turn off *Confirm email* so new accounts can sign in immediately. Leave it on for production.

### 3. Configure environment variables

```bash
cp .env.example .env
```

Fill in `.env`: `GEMINI_API_KEY`, `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`.
The anon key is designed to be public. The **Gemini key stays on the server only**. Never put it in a `VITE_` variable.

`GEMINI_MODELS` is a comma-separated list for the model picker (first = default). Model names change over time, so check the [Gemini models page](https://ai.google.dev/gemini-api/docs/models) and edit the list if a model is retired.

### 4. Run

```bash
npm run dev
```

Open **http://localhost:5173**, create an account, and start chatting. (API runs on port 8787 and is proxied automatically.)
Settings → AI shows whether the server is missing any variables.

## Upload to GitHub

```bash
cd abhi-ai
git init
git add .
git commit -m "Initial commit: ABHI AI"
git branch -M main
git remote add origin https://github.com/<your-username>/abhi-ai.git
git push -u origin main
```

Create the empty `abhi-ai` repository on github.com first (no README). `.gitignore` already excludes `.env` and `node_modules`. Run `git status` before committing and confirm `.env` is **not** listed.

## Deploy to Vercel

1. Push the project to GitHub (above).
2. On [vercel.com](https://vercel.com) choose **Add New → Project** and import the repo. Framework preset can stay *Other*; `vercel.json` handles the build.
3. Add these **Environment Variables**: `GEMINI_API_KEY`, `GEMINI_MODELS` (optional), `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`.
4. Click **Deploy**.
5. In Supabase → **Authentication → URL Configuration**, set **Site URL** to your Vercel URL (needed for email confirmation links).

The frontend and API share one domain, so no CORS setup is needed.

## Use it as an Android app

Open your deployed site in Chrome on Android → menu (⋮) → **Add to Home screen / Install app**. It opens full-screen like a native app.
A Play Store APK is possible later by wrapping the same site with [Capacitor](https://capacitorjs.com) or Trusted Web Activity. That is a separate step.

## Security notes

- API keys are read from server environment variables only; the browser never sees them.
- Every API route requires a valid Supabase login; database access runs **as the signed-in user** with Row Level Security, so users can only read their own data.
- Inputs are validated with Zod, headers set by Helmet, and requests rate-limited (20 chat messages/min and 120 API calls/min per IP).
- Uploaded files are sent to Gemini for that one request and are **not stored**; only the file name is kept in history.
- Markdown from the AI is rendered without raw HTML.

## Limitations to know about

- Voice input uses the browser's Web Speech API: works best in **Chrome / Edge** (including Android). Firefox lacks it, and Safari support varies. Telugu/Hindi *spoken* voices depend on what your device has installed.
- Vercel limits request bodies to 4.5 MB, so attachments total about 3 MB (photos are auto-shrunk; PDFs over ~3 MB won't upload).
- Follow-up questions in Image analysis re-send the image each time, because images are not stored.
- Web search availability and pricing depend on your Gemini plan and model.

## Troubleshooting

| Problem | Fix |
| --- | --- |
| "Setup needed" on the login page | `VITE_SUPABASE_URL` / `VITE_SUPABASE_ANON_KEY` missing in `.env`; restart `npm run dev` |
| "Gemini rejected the request" | Check `GEMINI_API_KEY` and that the model in `GEMINI_MODELS` exists for your key |
| "model not found" | Update `GEMINI_MODELS` with a current model name |
| Can't sign in after registering | Email confirmation is on: click the link in your inbox, or disable it for testing |
| Profile or history errors | Run `supabase/schema.sql` again (it is safe to re-run) |
| Mic does nothing | Allow microphone permission; use Chrome/Edge; the site must be on `localhost` or HTTPS |
| `npm run typecheck` shows errors | Send them to Claude with the file names and it can fix them |

## Scripts

`npm run dev` · `npm run build` · `npm start` (serves API + built site) · `npm run typecheck`
