import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// The frontend lives in /client. The API runs on :8787 locally and is proxied under /api.
export default defineConfig({
  root: 'client',
  envDir: '..',
  plugins: [react()],
  build: { outDir: '../dist', emptyOutDir: true },
  server: {
    port: 5173,
    proxy: { '/api': { target: 'http://localhost:8787', changeOrigin: true } },
  },
});
